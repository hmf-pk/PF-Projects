#include<iostream>
using namespace std;
int main()
{
// r,c,b is three variable declare
// R mean rickshaws
    int r =0;
// c mean car 
  int c=0;
	// r means buses
	int b =0;
	// U for User input
	int u_input;
	// amount, count is two variable declare
	int amount=0,count=0;

	// menu
	while (true)
	{
	cout<<"***************WELCOME***************"<<endl;
	cout<<"press 1 for rickshaw"<<endl;
	cout<<"press 2 for car"<<endl;
	cout<<"press 3 for bus"<<endl;
	cout<<"press 4 to show the record"<<endl;
	cout<<"press 5 to delete the record"<<endl;
	cin>>u_input;
if (u_input==1)
{
	// Requriment is only 50
	if (count<=50)
	{
	r= r+1;
	// one rickshaw per charge is 100
	amount = amount + 100;
	count =count + 1;
	}
else
cout<<" parking is full"<<endl;
}
 else if (u_input==2)	
{
   if (count<=50)
   {
   c++;
   // one car per charge is 200
	amount = amount + 200;
    count = count + 1;
	}
else
cout <<"parking is full"<<endl;
}
else if (u_input==3)	
{
	if (count<=50)
	{
	b++;
	// one bus per charge is 300
	amount = amount + 300;
	count = count + 1;
}
else
cout<<"parking is full"<<endl;
}
else if (u_input==4)	
{
	// user input is 4 than result is shown otherwise result is not shown
	cout<<"********************************************************"<<endl;
		cout <<"the total amount ="<<amount<<endl;
		cout<<"the total number of vehicles parked="<<count<<endl;
			cout<<"the total number of rickshaws parked="<<r<<endl;
			cout<<"the total number of cars parked="<<c<<endl;
			cout<<"the total number of buses parked="<<b<<endl;
		cout<<"****************************************************"<<endl;
	}
else if (u_input==5)
{
// if user input is 5 then record well be deleted
	amount = 0;
	count = 0;
	r=0;
	c=0;
	b=0;
	cout<<"*************************************"<<endl;
	  cout<<"RECORD DELETE"<<endl;
	cout<<"*************************************"<<endl;  
}
else 
{
	// otherwise User incorrect input then show invalid  number
	cout <<"Invalid number"<<endl;
}

}
     return 0;

}		



	
