//BENS GAMING ZONE
#include<bits/stdc++.h>
using namespace std;

void main_banner();      //------ For Main Display
string Authentication;   //------For Main Display

void c_banner();                              //------------For Casino Game
string Player_Name();
string Players_Name;                       //
int Deposit_Amount();                      //
int Deposite_Amount;                       //
void Rules_For_Player_To_Play_Game();      //
int Current_Balance_Of_Player();           //
int Current_Balance_Of_the_Player;         //
int Bet();                                 //
int Bet_Amount;                            //
int Player_Guess_Number();                 //
int Player_Number;                         //
int Player_choose;                         //
int Computer_Guess_Number();               //
int Computer_Number;                       //
int computer_choose;                       //
void Show_Result();                        //----------------- For Casino Game


//---------------------------------For Rock , Paper ,Scissor
void R_banner();                                            //
char getUserInput();                                        //
char getComputerInput();                                    //
void showChoice(char input);                                //
void showWinner(char ,char);                                //
//---------------------------------For Rock , Paper ,Scissor





//---------------------------------HangMan Game
void H_banner();                             // 
void hanging_pool();                         //
void blanks();                               //
char player_guessing_number();               //
                                             //
char head_of_man;                            //
char body_of_man1;                           //
char body_of_man2;                           //
char legs_of_man1;                           //
char legs_of_man2;                           //
                                             //
char blank1='_';                             //
char blank2='_';                             //
char blank3='_';                             //
char blank4='_';                             // 
char blank5='_';                             //
                                             //
char guess_number;                           //
                                             //
char choose;                                 // 
                                             //
 bool gameevoer;                             //
//----------------------------------HangMan Game




//------------------------------------------------------------Circle Cross Game
char board[3][3]={{'1','2','3'},{'4','5','6'},{'7','8','9'}};                 //
char turn='X';                                                                //
int row,column;                                                               //
void board_display();                                                         //
void player_turn();                                                           //
bool game_over();                                                             //
//------------------------------------------------------------Circle Cross Game 







main()
{
	//That is showing the Main banner of BENS GAMING ZONE
	main_banner();
	//That is to Authentication Process
	string Users_ID;
jumpA:cout<<"\t\t\t\t\tEnter User ID that is given to you by Ben,In order to enter into the BENS GAMING ZONE! :";
	cin>>Users_ID;
	string Password;
	cout<<"\t\t\t\t\tEnter User Password that is given to you by Ben,In order to enter into the BENS GAMING ZONE! :";
	cin>>Password;
	
	//If the User ID and Password is correct Then Player will entered into BENS GAMING ZONE
	if(Users_ID=="thefewtheproud" && Password=="cadet0909")
	{
		jump0:cout<<"\t\t\t\t\tI WELCOME YOU IN BENS GAMING ZONE ON THE BEHALF OF BEN"<<endl;
		cout<<"\t\t\t\t\tI am MICHAEL\n\t\t\t\t\tI AM AI\n\t\t\t\t\tI WILL GUIDE YOU HERE"<<endl;
		cout<<"\t\t\t\t\tFor now we have four game which are available"<<endl;
		cout<<"\t\t\t\t\t(1) Casino Game \n\t\t\t\t\t(2) Rock , Paper ,Scissor Game \n\t\t\t\t\t(3) HangMan Game \n\t\t\t\t\t(4) Cross Circle Game"<<endl;
	    //That is to choose the game which player wants to play 
		int M_choose;
	    cout<<"\n\n\n\t\t\t\t\t Which game do you want to play?";
	    cin>>M_choose;
	    //that will start Casino Game
	    if(M_choose==1)    //----------------------------------------------------------------------------game1
	    {                                                                                                   //
	    	//That function is for Banner                                                                   //
	jump1: c_banner();                                                                                      //
	//That function is to take player's name                                                                //
	Players_Name=Player_Name();                                                                             //
	//That function is for player to deposite his/her amount in order to play game                          //
	Deposite_Amount=Deposit_Amount();                                                                       //
	//That function is to show the rules of the game                                                        //
	Rules_For_Player_To_Play_Game();                                                                        //
	//That function is to show the current balance of the player                                            //
	Current_Balance_Of_Player();                                                                            //
	//That function is to take the Bet Amount from the player                                               //
	Bet();                                                                                                  //
	//That function is to show the Player guess number                                                      //
	Player_Number=Player_Guess_Number();                                                                    //
	//That function is to show the winner number                                                            //
	Computer_Number=Computer_Guess_Number();                                                                //
	//That will show the result                                                                             //
	Show_Result();                                                                                          //
	int jump1;                                                                                              //
	cout<<"\nPress 1 to replay game"<<endl;                                                                 //
	cout<<"Press 2 to goto exit for game and goto main screen"<<endl;                                       //
	cin>>jump1;                                                                                             //
	if(jump1==1)                                                                                            // 
	{                                                                                                       //
		goto jump1;                                                                                         //
	 }                                                                                                      //
	 else if(jump1==2)                                                                                      //
	 {                                                                                                      //
	 	goto jump0;                                                                                         //
	 }                                                                                                      //
		}                                                                                                   //
	 //--------------------------------------------------------------------------------------------------game1
		
		
		
		
		
		
		
		//that will start HangMan Game
		else if(M_choose==2)     //----------------------------------------------------------------------------game2
		{                                                                                                         //
	jump2:		system("cls");                                                                                    //
	R_banner();                                                                                                   //
	// user choice                                                                                                //
	char user_input , computer_input;                                                                             //
	user_input = getUserInput();                                                                                  //                                                           
	cout<<"Your choice is :" <<endl;                                                                              //
	showChoice(user_input);                                                                                       //                               
	//Computer choice                                                                                             //                         
	computer_input = getComputerInput();                                                                          //                                            
	cout<<"Computer choice is :" <<endl;                                                                          //
	showChoice(computer_input);                                                                                   //                                   
	// Show Winner                                                                                                //
	showWinner(user_input , computer_input);                                                                      //
	int jump2;                                                                                                    //
	cout<<"\nPress 1 to replay game"<<endl;                                                                       //
	cout<<"Press 2 to goto exit for game and goto main screen"<<endl;                                             //
	cin>>jump2;                                                                                                   //
	if(jump2==1)                                                                                                  //                     
	{                                                                                                             //
		goto jump2;                                                                                               //                       
	 }                                                                                                            //           
	 else if(jump2==2)                                                                                            //                          
	 {                                                                                                            //                                                                     
	 	goto jump0;                                                                                               //                       
	 }                                                                                                            //          
	return 0;                                                                                                     //                 
		}                                                                                                         //             
	//---------------------------------------------------------------------------------------------------------game2
		
		
		
		
		
		
		
		
		
		//that will start Rock , Paper ,Scissor Game
		else if(M_choose==3)     //-----------------------------------------------------------------------------------game3
	                                                                                                                     //
		{                                                                                                                //                                
			while(gameevoer!=true)                                                                                       //                                                         
	{                                                                                                                    //                            
                                                                                                                         //                       
	jumpp1: system("cls");                                                                                               //
	 H_banner();                                                                                                         //
	hanging_pool();                                                                                                      //                                          
	blanks();                                                                                                            //                                                                                                            
	guess_number=player_guessing_number();                                                                               //
    if(head_of_man=='o' && body_of_man1=='/' && body_of_man2=='|' && legs_of_man1=='|' && legs_of_man2=='|')             //
			{                                                                                                            //                                    
				cout<<"Your Are Dead";                                                                                   //                                                             
				gameevoer=true;                                                                                          //                                                      
			}                                                                                                            //                                    
			else if(blank1=='g' && blank2=='a' && blank3=='m' && blank4=='e' && blank5=='s')                             //                                           
			{                                                                                                            //                                    
				cout<<"You Win!";                                                                                        //                                                        
				gameevoer=true;                                                                                          //                                                      
			}                                                                                                            //                                    
                                                                                                                         //                       
	switch(choose)                                                                                                       //                                         
	{                                                                                                                    //                            
		case 'g':                                                                                                        //                                        
			blank1='g';                                                                                                  //                                              
			break;                                                                                                       //                                         
		case 'a':                                                                                                        //                                        
			blank2='a';                                                                                                  //                                              
			break;                                                                                                       //                                         
		case 'm':                                                                                                        //                                                                                                                
			blank3='m';                                                                                                  //                                              
			break;                                                                                                       //                                         
		case 'e':                                                                                                        //                                        
			blank4='e';                                                                                                  //                                               
			break;                                                                                                       //                                         
		case 's':                                                                                                        //                                        
			blank5='s';                                                                                                  //                                              
			break;                                                                                                       //                                         
		default:                                                                                                         //                                       
			if(head_of_man=='o' && body_of_man1!='/')                                                                    //                                                                            
			{                                                                                                            //                                    
				body_of_man1='/';                                                                                        //                                                        
				goto jumpp1;                                                                                             //                                                   
			}                                                                                                            //                                    
			if(head_of_man=='o' && body_of_man1=='/' && body_of_man2!='|')                                               //                         
			{                                                                                                            //                                    
				body_of_man2='|';                                                                                        //                                                        
				goto jumpp1;                                                                                             //                                                   
				                                                                                                         //                                       
			}                                                                                                            //                                    
			if(head_of_man=='o' && body_of_man1=='/' && body_of_man2=='|' && legs_of_man1!='|')                          //                                              
			{                                                                                                            //                                    
				legs_of_man1='|';                                                                                        //                                                                                                                                
				goto jumpp1;                                                                                             //                                                   
				                                                                                                         //                                       
			}                                                                                                            //                                    
			if(head_of_man=='o' && body_of_man1=='/' && body_of_man2=='|' && legs_of_man1=='|')                          //                                              
			{                                                                                                            //                                    
				legs_of_man2='|';                                                                                        //                                                        
			//	goto jumpp2;				                                                                             //                                                                   
	        }                                                                                                            //                                    
	        else                                                                                                         //                                       
	        {                                                                                                            //                                    
	        	head_of_man='o';                                                                                         //                                                       
			}                                                                                                            //                                    
			                                                                                                             //                                   
                                                                                                                         //                       
    }                                                                                                                    //                            
	}                                                                                                                    //                            
                                                                                                                         //                       
     goto jump0;                                                                                                         //                                       
	                                                                                                                     //                           
                                                                                                                         //                       
    }                                                                                                                    //                        
	                                                                                                                     //                           
	//----------------------------------------------------------------------------------------------------------------game3	
		
		
		
		
		
		
		
		//that will start Cross Circle Game
		else if(M_choose==4)   //----------------------------------------------------------------------------game4
		{                                                                                                       //
	      while(game_over())                                                                                    //
	{                                                                                                           //                                   
	  board_display();                                                                                          //                                                    
	                                                                                                            //                                  
	  player_turn();                                                                                            //
	                                                                                                            //                                    
	  board_display();                                                                                          //                                                    
	}                                                                                                           //                                     
 cout<<"GAME IS OVER"<<endl;                                                                                    //                                                                                                                                                                                                                                                                                                                                                                                                                             
 if(board[0][0]=='X' && board[0][1]=='X' && board[0][2]=='X' || board[1][0]=='X' && board[1][1]=='X' && board[1][2]=='X' || board[2][0]=='X' && board[2][1]=='X' && board[2][2]=='X' || board[0][0]=='X' && board[1][0]=='X' && board[2][0]=='X' || board[0][1]=='X' && board[1][1]=='X' && board[2][1]=='X' || board[0][2]=='X' && board[1][2]=='X' && board[2][2]=='X' || board[0][0]=='X' && board[1][1]=='X' && board[2][2]=='X' || board[0][2]=='X' && board[1][1]=='X' && board[2][0]=='X' )
 {                                                                                                              //                                
 	                                                                                                            //                                  
 	cout<<"Player1 is the winner";                                                                              //                                                                
 }                                                                                                              //                                
 else if(board[0][0]=='O' && board[0][1]=='O' && board[0][2]=='O' || board[1][0]=='O' && board[1][1]=='O' && board[1][2]=='O' || board[2][0]=='O' && board[2][1]=='O' && board[2][2]=='O' || board[0][0]=='O' && board[1][0]=='O' && board[2][0]=='O' || board[0][1]=='O' && board[1][1]=='O' && board[2][1]=='O' || board[0][2]=='O' && board[1][2]=='O' && board[2][2]=='O' || board[0][0]=='O' && board[1][1]=='O' && board[2][2]=='O' || board[0][2]=='O' && board[1][1]=='O' && board[2][0]=='O')
 {                                                                                                              //                                
 	cout<<"Player2 is the winner";                                                                              //                                                                
 }                                                                                                              //                                
 else if((board[0][0]=='X' || board[0][0]=='O') && (board[0][1]=='X' || board[0][1]=='O') && (board[0][2]=='X' || board[0][2]=='O') && (board[1][0]=='X' || board[1][0]=='O') && (board[1][1]=='X' || board[1][1]=='O') && (board[1][2]=='X' || board[1][2]=='O') && (board[2][0]=='X' || board[2][0]=='O') && (board[2][1]=='X' || board[2][1]=='O') && (board[2][2]=='X' || board[2][2]=='O'))
 {                                                                                                              //                                
 	cout<<"Game IS DRAW!\nBoth Players are lusers\nHAHAHAHAHAAH";                                               //                        
 }                                                                                                              //                                
	                                                                                                            //                                   
}                                                                                                               //                               
   int jump4;                                                                                                   //                                           
   cout<<"\nEnter 1 to play other games\nEnter 2 to close program:";                                            //                           
   cin>>jump4;                                                                                                  //                                            
   if(jump4==1)                                                                                                 //                                                                                                                    
   {                                                                                                            //                                  
   	goto jump0;                                                                                                 //                                             
   }                                                                                                            //                                  
                                                                                                                //                                 
}                                                                                                               //                               
 else                                                                                                           //                                   
 {                                                                                                              //                                
 	cout<<"\t\t\t\t\t\t\t\t\tInValid UserName and ID"<<endl;                                                    //                   
 	goto jumpA;                                                                                                 //                                             
 }                                                                                                              //
 //----------------------------------------------------------------------------------------------------------game4
                                                                                                                                              
}                                                                               




                                                               
                                                                                                                                              
//===================================Functions======================================

void main_banner()
{
	cout<<"\t\t\t\t\t\t|===================================================================|"<<endl;
	cout<<"\t\t\t\t\t\t|                                                                   |"<<endl;
	cout<<"\t\t\t\t\t\t|                   WELCOME TO BENS GAMING ZONE                     |"<<endl;
	cout<<"\t\t\t\t\t\t|                                                                   |"<<endl;
	cout<<"\t\t\t\t\t\t|===================================================================|"<<endl;
}








//========================================now start casino game===========================================================                                                           
void c_banner()
{
	cout<<"\t\t\t\t\t\t\t  |------------------------------------------------|"<<endl;
	cout<<"\t\t\t\t\t\t\t  |         WELCOME TO BEN'S CASINO GAME           |"<<endl;
	cout<<"\t\t\t\t\t\t\t  |         OWNER ABDULLAH BIN SIKANDAR            |"<<endl;
	cout<<"\t\t\t\t\t\t\t  |------------------------------------------------|"<<endl;
}

string Player_Name()
{
	string Name;
	cout<<"Enter your name please : ";
	cin>>Name;
	return Name;
}

int Deposit_Amount()
{
	int Deposit_Amount;
	cout<<"Enter Deposite Amount to play game : $ ";
	cin>>Deposit_Amount;
	return Deposit_Amount;
}

void Rules_For_Player_To_Play_Game()
{
	system("cls");
	cout<<"\t\t\t\t\t\t\t|------------------------------------------------|"<<endl;
	cout<<"\t\t\t\t\t\t\t|                     RULES                      |"<<endl;
	cout<<"\t\t\t\t\t\t\t|------------------------------------------------|"<<endl;
	cout << "\t\t\t\t\t\t\t1. Choose any number between 1 to 10\n";
    cout << "\t\t\t\t\t\t\t2. If you win you will get 10 times of money you bet\n";
    cout << "\t\t\t\t\t\t\t3. If you bet on wrong number you will lose your betting amount"<<endl;
}

int Current_Balance_Of_Player()
{
	Current_Balance_Of_the_Player=Deposite_Amount;
	cout<<"Your Current Balance is : "<<Current_Balance_Of_the_Player<<endl;
	return 0;
}

int Bet()
{
	cout<<"Enter your Bet amount : $ ";
	cin>>Bet_Amount;
	return Bet_Amount;
}

int Player_Guess_Number()
{
	Player_choose;
	cout<<"Enter your number to bet : ";
	cin>>Player_choose;
	return Player_choose;
}

int Computer_Guess_Number()
{
	srand(time(0));
	computer_choose=rand() % 10 + 1;
	// cout<<"The Winner Number is : "<<choice;
	return computer_choose;
}

void Show_Result()
{
	if(Player_choose==computer_choose)
	{
		cout<<"Congratulations!\nYou are winner"<<endl;
		cout<<"Your Current Balance is :"<<Current_Balance_Of_the_Player*10;
		
	}
	else
	{
		cout<<"OOOOOOOOPPPPPSSSS! You Lose!"<<endl;
		cout<<"The winner number is : "<<Computer_Number<<endl;
		cout<<"Better Luck For Next Time"<<endl;
		cout<<"Your Current Balance is :"<<Current_Balance_Of_the_Player-Bet_Amount<<endl;
		
	}
}

//--------------------------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------------------------



//=======================================Rock , Paper , Scissor Game===================================================
void R_banner()
{
	cout<<"\t\t\t\t\t\t\t|-- -------------------------------------------|"<<endl;
	cout<<"\t\t\t\t\t\t\t|    WELCOME TO ROCK , PAPER , SCISSOR GAME    |"<<endl;
	cout<<"\t\t\t\t\t\t\t|         OWNER ABDULLAH BIN SIKANDAR          |"<<endl;
	cout<<"\t\t\t\t\t\t\t|-- -------------------------------------------|"<<endl;
}


char getUserInput()
{
	char choice;
	cout<<"Choose your option: "<<endl;
	cout<<" (r) for Rock , (p) for paper , (s) for scissor" <<endl;
	cin>>choice;
	while(choice != 'r' && choice != 'p' && choice != 's')
	{
		system("cls");
		R_banner();
		cout<<"Invalid Choice :" <<endl;
		cout<<" (r) for Rock , (p) for paper , (s) for scissor" <<endl;
		cin>>choice;
	}
	return choice;
}

char getComputerInput()
{
	srand(time(0));
	int choice = rand() % 3 + 1;
	if(choice == 1)
	{
		return 'r';
	}
	else if(choice == 2)
	{
		return 'p';
	}
	
	return 's';
}

void showChoice(char input)
{
	if(input == 'r')
	{
	cout<< "Rock"  <<endl;
	}
	
	if(input == 'p')
	{
	cout<< "Paper"  <<endl;
	}
	
	if(input == 's')
	{
	cout<< "Scissor"  <<endl;
	}
}



void showWinner(char user_input , char computer_input)
{
	if(user_input == 'r' && computer_input == 's')
	{
		cout<<"You Win! rock smashes the scissors"<<endl;
	}
	else if(user_input == 'p' && computer_input == 'r')
	{
		cout<<"You Win! paper wraps the rock "<<endl;
	}
	else if(user_input == 's' && computer_input == 'p')
	{
		cout<<"You Win!scissors cuts the paper"<<endl;
	}
	else if(computer_input == 'r' && user_input == 's')
	{
		cout<<"computer Win! rock smashes the scissors"<<endl;
	}
	else if(computer_input == 'p' && user_input == 'r')
	{
		cout<<"computer Win! paper wraps the rock "<<endl;
	}
	else if(computer_input == 's' && user_input == 'p')
	{
		cout<<"computer Win!scissors cuts the paper"<<endl;
	}
	else
	{
		cout<<"Tie, Again play the game and try to win" <<endl;
	}
}
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------





//================================================HangMan Game=============================================================

void H_banner()
{
	cout<<"\t\t\t\t\t\t\t\t|-----------------------|"<<endl;
	cout<<"\t\t\t\t\t\t\t\t|WELCOME TO HANGMAN GAME|"<<endl;
	cout<<"\t\t\t\t\t\t\t\t|      MADE BY BEN      |"<<endl;
	cout<<"\t\t\t\t\t\t\t\t|-----------------------|"<<endl;
	cout<<"\n\n\t\t\t\t\t\\t\ttIF YOU COMPLETE THE BLANKS,THEN PLEASE WRITE YOUR NAME"<<endl;
	cout<<"\n\t\t\t\t\t\t\t\tIF YOU MISS YOU FIVE TRIES,THEN ALSO WRITE YOUR NAME"<<endl;
	
}

void hanging_pool()
{
	cout<<"\n\n\t\t\t\t\t\t     +-----+     "<<endl;
	cout<<"\t\t\t\t\t\t     |      |     "<<endl;
	cout<<"\t\t\t\t\t\t    "<<head_of_man<<"       |     "<<endl;
	cout<<"\t\t\t\t\t\t    "<<body_of_man1<<"       |     "<<endl;
	cout<<"\t\t\t\t\t\t    "<<body_of_man2<<"       |     "<<endl;
	cout<<"\t\t\t\t\t\t    "<<legs_of_man1<<"       |     "<<endl;
	cout<<"\t\t\t\t\t\t    "<<legs_of_man2<<"       |     "<<endl;
	cout<<"\t\t\t\t\t\t===================="<<endl;
}

void blanks()
{
	cout<<blank1<<blank2<<blank3<<blank4<<blank5<<endl;
}

char player_guessing_number()
{
	cout<<"Enter your guess"<<endl;
	cin>>choose;
	return choose;
}
//------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------







//===============================================Circle cross Game========================================================



void board_display()    
{
	//That is the board for game.
	system("cls");
	cout<<"\t\t WELCOME TO TAK TOE GAME"<<endl;
	cout<<"\t\t PLAYER1  [X]"<<endl;
	cout<<"\t\t PLAYER2  [O]"<<endl;
	cout<<"\t\t\t\t     |     |     "<<endl;
	cout<<"\t\t\t\t  "<<board[0][0]<<"  |  "<<board[0][1]<<"  |  "<<board[0][2]<<"  "<<endl;
	cout<<"\t\t\t\t_____|_____|_____"<<endl;
	cout<<"\t\t\t\t     |     |     "<<endl;
	cout<<"\t\t\t\t  "<<board[1][0]<<"  |  "<<board[1][1]<<"  |  "<<board[1][2]<<"  "<<endl;
	cout<<"\t\t\t\t_____|_____|_____"<<endl;
	cout<<"\t\t\t\t     |     |     "<<endl;
	cout<<"\t\t\t\t  "<<board[2][0]<<"  |  "<<board[2][1]<<"  |  "<<board[2][2]<<"  "<<endl;
	cout<<"\t\t\t\t     |     |     "<<endl;
}

void player_turn()
{
	int choice;
	if(turn=='X')
	               {
	                 cout<<"Player1 Turn[X]:";
                    }
    if(turn=='O')
	               {
	                 cout<<"Player2 Turn[O]:";
                    }
	cin>>choice;
	switch(choice)
	{
		case 1:
			   row=0;
			   column=0;
			   break;
		case 2:
			   row=0;
			   column=1;
			   break;
		case 3:
			   row=0;
			   column=2;
			   break;
		case 4:
			   row=1;
			   column=0;
			   break;
		case 5:
			   row=1;
			   column=1;
			   break;
		case 6:
			   row=1;
			   column=2;
			   break;
		case 7:
			   row=2;
			   column=0;
			   break;
		case 8:
			   row=2;
			   column=1;
			   break;
		case 9:
			   row=2;
			   column=2;
			   break;	   	   	   	   	   	   	   	   
	}
		if(turn=='X' && board[row][column]!='X' && board[row][column]!='O')
	{
	  board[row][column]='X';
	  turn='O';
    }
    else if(turn=='O' && board[row][column]!='X' && board[row][column]!='O')
    {
     board[row][column]='O';
	 turn='X';
    }
    else
    {
    	cout<<"Box is already filled"<<endl;
	}
	
}

bool game_over()
{
	int Game_OVER;
	//Check for win
	for(int i=0;i<3;i++)

		if(board[i][0] == board[i][1]  && board[i][0] == board[i][2])
		return false;
		
	for(int k=0;k<3;k++)

		if(board[0][k] == board[1][k] && board[0][k] == board[2][k])
		return false;
		
	
	    if(board[0][0] == board[1][1] && board[0][0] == board[2][2])
	    return false;
	    
	    if(board[0][2] == board[1][1] && board[0][2] == board[2][0])
	    return false;
	    
	    if((board[0][0]=='X' || board[0][0]=='O') && (board[0][1]=='X' || board[0][1]=='O') && (board[0][2]=='X' || board[0][2]=='O') && (board[1][0]=='X' || board[1][0]=='O') && (board[1][1]=='X' || board[1][1]=='O') && (board[1][2]=='X' || board[1][2]=='O') && (board[2][0]=='X' || board[2][0]=='O') && (board[2][1]=='X' || board[2][1]=='O') && (board[2][2]=='X' || board[2][2]=='O'))
	    return false;
	    
	    
	//check if any box is not filled
	for(int i=0;i<3;i++)
	for(int j=0;j<3;j++)
	if(board[i][j]!='X' && board[i][j]!='O')
	   return true;
	
}
//----------------------------------------------------------------------------------------------------------------------