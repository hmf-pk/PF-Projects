#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int rollDice()
 {
    return rand() % 6 + 1;
}

void displayBoard(int player1, int player2)
 {
    cout << "Player 1: " << player1 << endl;
    cout << "Player 2: " << player2 << endl;

    cout << "\nLudo Board:\n";
    for (int i = 0; i < 4; ++i) 
	{
        for (int j = 0; j < 4; ++j) {
            cout << "|__";
        }
        cout << "|\n";
        for (int j = 0; j < 4; ++j)
		 {
            cout << "|  ";
        }
        cout << "|\n";
    }
}

int movePlayer(int player, int steps)
 {
    int newPosition = player + steps;
    if (newPosition <= 100) 
	{
        player = newPosition;
    }
    return player;
}

void ludoGame() 
{
    int player1 = 0;
    int player2 = 0;

    srand(time(0)); // Seed for random number generation

    while (player1 < 100 && player2 < 100) 
	{
        cout << "Press Enter for Player 1's turn...";
        cin.ignore(); // Wait for Enter key
        int steps = rollDice();
        cout << "Player 1 rolled a " << steps << ".\n";
        player1 = movePlayer(player1, steps);
        displayBoard(player1, player2);

        

        cout << "Press Enter for Player 2's turn...";
        cin.ignore(); // Wait for Enter key
        steps = rollDice();
        cout << "Player 2 rolled a " << steps << ".\n";
        player2 = movePlayer(player2, steps);
        displayBoard(player1, player2);

        if (player2 == 100)
		{
            cout << "Player 2 wins!\n";
            break;
        }
    }
}

int main()
 {
    ludoGame();
    return 0;
}
