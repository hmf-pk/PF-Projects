#include <iostream>
#include <unistd.h>
#include <iomanip>
#include <windows.h>
using namespace std;

int marks = 0;

void wait();

void english();
	void englishTopic1();
	void englishTopic2();
	void englishTopic3();

void programming();
	void programmingTopic1();
	void programmingTopic2();
	void programmingTopic3();

void ict();
	void ictTopic1();
	void ictTopic2();
	void ictTopic3();

void physics();
	void physicsTopic1();
	void physicsTopic2();
	void physicsTopic3();

void calculus();
	void calculusTopic1();
	void calculusTopic2();
	void calculusTopic3();

void login();
void subjects();
void print_question(string question1[]);

void setCursorPosition(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

void drawBox(int width, int height, int x, int y) {
    for (int i = 0; i < height; ++i) {
        setCursorPosition(x, y + i);
        if (i == 0 || i == height - 1) {
            cout << setw(width) << setfill('*') << '*';
        } else {
            cout << '*' << setw(width - 1) << setfill(' ') << '*';
        }
    }
}

int main()
{
	
	login();
	int choice;
	cout << "\n\n1.Go to Subject Selection\n";
	cout << "2.Exit\n";
	cout << "Enter Your choice: ";
	cin >> choice;
	switch(choice)
	{
		case 1:   subjects();   break;
		case 2:   exit(1);      break;
	}
	return 0;
}

void wait()
{
	
cout << "Authenticating";
for(int i = 1; i <= 3; i++)
{
	cout << ".";
	sleep(1);
}

}

void login()
{
const int boxWidth = 40;
const int boxHeight = 12;

int centerX = (120 - boxWidth) / 2;
int centerY = (30 - boxHeight) / 2; 

string userPass[2] = {};
string user, pass;

drawBox(boxWidth, boxHeight, centerX, centerY);

setCursorPosition(centerX + 5, centerY + 2);
cout << "Register yourself." << endl;

setCursorPosition(centerX + 5, centerY + 4);
cout << "Enter Username: ";
cin >> userPass[0];

setCursorPosition(centerX + 5, centerY + 5);
cout << "Enter Password: ";
cin >> userPass[1];

system("CLS");

drawBox(boxWidth, boxHeight, centerX, centerY);

setCursorPosition(centerX + 5, centerY + 2);
cout << "Registered Successfully." << endl;

setCursorPosition(centerX + 5, centerY + 4);
cout << "Now Login." << endl;

setCursorPosition(centerX + 5, centerY + 6);
cout << "Enter Username: ";
cin >> user;

setCursorPosition(centerX + 5, centerY + 7);
cout << "Enter Password: ";
cin >> pass;

setCursorPosition(centerX + 5, centerY + 9);
wait();

system("CLS");

while (user != userPass[0] || pass != userPass[1]) {
    drawBox(boxWidth, boxHeight, centerX, centerY);

    setCursorPosition(centerX + 5, centerY + 2);
    cout << "Invalid Username or Password." << endl;

    setCursorPosition(centerX + 5, centerY + 6);
    cout << "Enter Username: ";
    cin >> user;

    setCursorPosition(centerX + 5, centerY + 7);
    cout << "Enter Password: ";
    cin >> pass;
}

system("CLS");
cout << "Login Successful." << endl;

	subjects();

}

void subjects()
{
	int choice;

	cout << "\nChoose a Subject for Quiz." << endl;
	cout << "1." << "Functional English" << endl;
	cout << "2." << "Programming Fundamental" << endl;
	cout << "3." << "Information Communicaton Technology(ICT)" << endl;
	cout << "4." << "Applied Physics" << endl;
	cout << "5." << "Calculus(Quantitative Reasoning)" << endl;
	cout << "6." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
    
	
	while( choice < 1 || choice > 6)
	{
		system("CLS");
    cout << "Invalid Choice.Try Again.\n";
	cout << "\nChoose a Subject for Quiz." << endl;
	cout << "1." << "Functional English" << endl;
	cout << "2." << "Programming Fundamental" << endl;
	cout << "3." << "Information Communicaton Technology(ICT)" << endl;
	cout << "4." << "Applied Physics" << endl;
	cout << "5." << "Calculus(Quantitative Reasoning)" << endl;
	cout << "6." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
    }
    
	switch(choice)
	{
		case 1:		english();		break;
		case 2:		programming();	break;
		case 3:		ict();			break;
		case 4:		physics();		break;
		case 5:		calculus();		break;
		case 6:		exit(1);		break;
		default:	cout << "Sorry! No Match";		break;
	}
}

// Subjects Functions

void english()
{
	system("CLS");
	
    int choice;
	
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "7 C's of Communication" << endl;
	cout << "2." << "Word Formation" << endl;
	cout << "3." << "Puntuation" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
	
	while( choice < 1 || choice > 4)
	{
	system("CLS");

	cout << "Invalid Choice.Try Again.\n";
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "7 C's of Communication" << endl;
	cout << "2." << "Word Formation" << endl;
	cout << "3." << "Puntuation" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
		
	}
		
	switch(choice)
    {  
		case 1:		englishTopic1();		break;
		case 2:		englishTopic2();	break;
		case 3:		englishTopic3();			break;
		case 4:		exit(1);		break;
		default:	cout << "Sorry! No Match";		break;
    }
}

void programming()
{
	system("CLS");
		
    int choice;
		
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Datatypes" << endl;
	cout << "2." << "Operators" << endl;
	cout << "3." << "Functions" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
	
	while( choice < 1 || choice > 4)
	{
	system("CLS");

	cout << "Invalid Choice.Try Again.\n";
	
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Datatypes" << endl;
	cout << "2." << "Operators" << endl;
	cout << "3." << "Functions" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
		
	}
		
	switch(choice)
    {  
		case 1:		programmingTopic1();		break;
		case 2:		programmingTopic2();	break;
		case 3:		programmingTopic3();			break;
		case 4:		exit(1);		break;
		default:	cout << "Sorry! No Match";		break;
    }
}

void ict()
{
	system("CLS");
	int choice;
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Internet" << endl;
	cout << "2." << "Buses" << endl;
	cout << "3." << "Topologies" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;

	while( choice < 1 || choice > 4)
	{
	system("CLS");
	
	cout << "Invalid Choice.Try Again.\n";
	
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Internet" << endl;
	cout << "2." << "Buses" << endl;
	cout << "3." << "Topologies" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
		
	}

		
	switch(choice)
    {  
		case 1:		ictTopic1();		break;
		case 2:		ictTopic2();	break;
		case 3:		ictTopic3();			break;
		case 4:		exit(1);		break;
		default:	cout << "Sorry! No Match";		break;
    }
}

void physics()
{
	system("CLS");
	
    int choice;	
    
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Electric Feild" << endl;
	cout << "2." << "Electric Flux" << endl;
	cout << "3." << "Screw Guage" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;

	while( choice < 1 || choice > 4)
	{
	system("CLS");
	
	cout << "Invalid Choice.Try Again.\n";
	
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Electric Feild" << endl;
	cout << "2." << "Electric Flux" << endl;
	cout << "3." << "Screw Guage" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
		
	}

		
	switch(choice)
    {  
		case 1:		programmingTopic1();		break;
		case 2:		programmingTopic2();	break;
		case 3:		programmingTopic3();			break;
		case 4:		exit(1);		break;
		default:	cout << "Sorry! No Match";		break;
    }
}

void calculus()
{
	system("CLS");
	
    int choice;
	
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Limit and continuity" << endl;
	cout << "2." << "Derevative" << endl;
	cout << "3." << "Integration" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;

	while( choice < 1 || choice > 4)
	{
	system("CLS");
	
	cout << "Invalid Choice.Try Again.\n";
	
	cout << "\nChoose a Topic for Quiz." << endl;
	cout << "1." << "Limit and continuity" << endl;
	cout << "2." << "Derevative" << endl;
	cout << "3." << "Integration" << endl;
	cout << "4." << "Exit" << endl;

	cout << "Enter your Choice: ";
	cin >> choice;
		
	}

		
	switch(choice)
    {  
		case 1:		programmingTopic1();		break;
		case 2:		programmingTopic2();	break;
		case 3:		programmingTopic3();			break;
		case 4:		exit(1);		break;
		default:	cout << "Sorry! No Match";		break;
    }
}

// Question Print Funtion

void print_question(string question[])
{
	system("CLS");
	
	cout << endl;
	string selected_option;
	
	cout << question[0] << endl;
	cout << "a) " << question[1] << endl;
	cout << "b) " << question[2]  << endl;
	cout << "c) " << question[3]  << endl;
	cout << "d) " << question[4]  << endl;
	cout << "Enter Your Answer: ";
	cin >> selected_option;
	
	if(selected_option == question[5])
	{
		marks++;
	}
}

// Topics Function

void englishTopic1()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which \"C\" of communication emphasizes the need to express ideas and information clearly and concisely?","Conciseness" ,"Clarity" ,"Courtesy" ,"Correctness" ,"b"};
	string question2[6] = {"What does the \"Correctness\" principle focus on in communication?", "Being polite", "Free from errors", "Inclusivity", "Keeping it brief", "b"};
	string question3[6] = {"Which \"C\" ensures that the message is easily understood and not confusing?", "Conciseness", " Clarity", "Correctness", "Completeness", "b"};
	string question4[6] = {"Which \"C\" involves being polite, respectful, and thoughtful in communication?","Conciseness" ,"Clarity" ,"Courtesy" ,"Correctness", "c"};
	string question5[6] = {"Which \"C\" of communication involves avoiding unnecessary details and presenting information clearly?","Conciseness" ,"Clarity" ,"Courtesy" ,"Correctness", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void englishTopic2()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"What is the term for the process of creating new words by combining two existing words?", "Compounding", "Derrivation", "Inflection", "Blending", "a"};
	string question2[6] = {"Which word formation process involves adding prefixes or suffixes to a base word to create a new word??", "Clipping", "Blending", "Derrivation", "Acronym", "c"};
	string question3[6] = {"What is the term for shortening a word by removing one or more syllables?", "Portmanteau", "Backformation", "Clipping", "Compounding", "c"};
	string question4[6] = {"Which word formation process involves creating a new word by combining parts of two existing words?", "Clipping", "Compounding", "Derrivation", "Blending", "d"};
	string question5[6] = {"What is the term for the process of creating a new word by removing an affix from an existing word?", "Backformation", "Acronym", "Compounding", "Derivation", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void englishTopic3()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which punctuation mark is used to indicate the end of a declarative sentence?", "Comma", "Exclamation mark", " Period (full stop)", "Question mark", "c"};
	string question2[6] = {"What punctuation mark is used to separate items in a list?", "Semicolon" ,"Colon" ,"Comma" ," Dash" ,"c"};
	string question3[6] = {"Which punctuation mark is used to indicate a sudden break or interruption in a sentence?", "Hyphen", "Dash", "Parentheses", "Quotation marks", "b"};
	string question4[6] = {"What punctuation mark is used to indicate possession or to show omission in contractions?", "Apostrophe", "Quotation marks", "Colon", "Exclamation mark", "a"};
	string question5[6] = {"Which punctuation mark is used at the end of a direct question?", "Exclamation mark", "Period (full stop)", "Semicolon", "Question mark", "d"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}

void programmingTopic1()
{
	char choice;
	marks = 0;
	
	cout << "Programming Quiz" << endl;
	
	string question1[6] = {"Which data type is used to store whole numbers in C++??", "Float", "String", "Int", "Double", "c"};
	string question2[6] = {"What is the size of the \"char\" data type in C++?", "2 bytes", "4 bytes", "1 bytes", "8 bytes", "c"};
	string question3[6] = {"Which data type is used to store decimal numbers in C++?", "Double", "String", "Int", "Bool", "a"};
	string question4[6] = {"Which data type is used to represent true or false values in C++?", "Float", "Bool", "String", "Double", "b"};
	string question5[6] = {"Which C++ data type is used to store characters and is enclosed in single quotes?", "Char", "String", "Bool", "Int", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void programmingTopic2()
{
	char choice;
	marks = 0;
	
	cout << "Programming Quiz" << endl;
	
	string question1[6] = {"Which operator is used for division in C++?", "/", "*", "%", "-", "a"};
	string question2[6] = {"What is the purpose of the \"++\" operator in C++?", "Decrement by 1", "Increment by 1", "Addition", "Subtraction", "b"};
	string question3[6] = {"Which operator is used for checking equality in C++?", "=", "!=", "==", "<=", "c"};
	string question4[6] = {"What is the purpose of the ternary operator \"?\" in C++?", "Conditional assignment", " Bitwise XOR", " Logical AND", "Division", "a"};
	string question5[6] = {"Which operator is used for finding the remainder of a division operation in C++?", "/", "*", "%", "-", "c"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void programmingTopic3()
{
	char choice;
	marks = 0;
	
	cout << "Programming Quiz" << endl;
	
	string question1[6] = {"What is the keyword used to declare a function in C++?", "define", "function", "declare", "void", "d"};
	string question2[6] = {"Which part of a function declaration specifies the type of data that the function will return?", "function body", "return type", "function name", "parameters", "b"};
	string question3[6] = {"What is the purpose of the \"return\" statement in a C++ function?", "End the program", "Return the value from the function", "Return the value from the program", "Return a variable", "b"};
	string question4[6] = {"Which type of function does not return any value in C++?", "Float", "void", "Int", "Double", "b"};
	string question5[6] = {"In C++, how are function arguments passed by default?", "By reference", "By pointer", "By value", "By address", "c"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}

void ictTopic1()
{
	char choice;
	marks = 0;
	
	cout << "ICT Quiz" << endl;
	
	string question1[6] = {"What does \"URL\" stand for in the context of the Internet?", "Universal Resource Locator", "Uniform Resource Link", "Unified Resource Locator", "Unique Resource Locator", "a"};
	string question2[6] = {"Which protocol is commonly used for secure communication over the Internet?", "HTTP", "FTP", "TCP", "HTTPS", "d"};
	string question3[6] = {"What does \"ISP\" stand for in the context of Internet services?", "Integrated Security Platform", "International Server Protocol", "Internet Service Provider", "Internet System Programming", "c"};
	string question4[6] = {"Which device is used to connect a local network to the Internet?", "Router", "Switch", "Modem", "Hub", "a"};
	string question5[6] = {"What is the purpose of DNS in the context of the Internet?", "Data Network Security", "Domain Name System", " Dynamic Network Service", "Digital Network Solution", "b"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void ictTopic2()
{
	char choice;
	marks = 0;
	
	cout << "ICT Quiz" << endl;
	
	string question1[6] = {"What is the primary function of the \"data bus\" in a computer system?", "Transfer control signals", "Transfer data between components", "Execute instructions", "Manage power supply", "b"};
	string question2[6] = {"Which type of bus connects the CPU to main memory in a computer system?", "Control bus", "Address bus", "Data bus", "Expansion bus", "c"};
	string question3[6] = {"What is the purpose of the \"address bus\" in a computer system?", "Transfer data", "Carry control signals", "Identify the location of data in memory", "Manage power distribution", "c"};
	string question4[6] = {"Which bus is responsible for carrying signals that control the operations of various components in a computer system?", "Control bus", "Address bus", "Data bus", "System bus", "a"};
	string question5[6] = {"Which bus is responsible for connecting the CPU to peripheral devices such as printers and external storage in a computer system?", "Control bus", "Data bus", "Adress bus", "Expansion bus", "d"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void ictTopic3()
{
	char choice;
	marks = 0;
	
	cout << "ICT Quiz" << endl;
	
	string question1[6] = {"In which network topology does each device have a direct connection to every other device in the network?", "Bus", "Star", "Ring", "Mesh", "d"};
	string question2[6] = {"What is the central point of connection in a star topology called?", "Node", "Hub", "Switch", "Router", "b"};
	string question3[6] = {"Which topology uses a single, central cable to connect all devices in the network?", "Bus", "Star", "Ring", "Mesh", "a"};
	string question4[6] = {"In a ring topology, what happens if one device in the network fails?", " The entire network becomes inoperable", "Only the affected device is affected", "The network reconfigures automatically", "Data transmission speeds up", "a"};
	string question5[6] = {"What is a disadvantage of a mesh topology?", "High reliability", "Low cost", "Complex to install and manage", "Complex to install and manage", "c"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}

void physicsTopic1()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question2[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question3[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question4[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question5[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void physicsTopic2()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question2[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question3[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question4[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question5[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void physicsTopic3()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question2[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question3[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question4[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question5[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}

void calculusTopic1()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question2[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question3[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question4[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question5[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void calculusTopic2()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question2[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question3[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question4[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question5[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
void calculusTopic3()
{
	char choice;
	marks = 0;
	
	cout << "English Quiz" << endl;
	
	string question1[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question2[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question3[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question4[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};
	string question5[6] = {"Which of the following is datatype for integers?", "Float", "String", "Int", "Double", "a"};

	print_question(question1);
	print_question(question2);
	print_question(question3);
	print_question(question4);
	print_question(question5);
	cout << "Marks Obtained: " << marks;

}
