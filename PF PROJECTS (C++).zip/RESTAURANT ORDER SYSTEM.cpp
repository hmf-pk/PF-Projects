#include<iostream>
#include<string>
#include<cstdlib>
using namespace std;
//			Defining function
int total_quantity(int Quantity_of_Fast,int Quantity_of_Desert,int Quantity_of_Drinks ) {
	return Quantity_of_Fast+Quantity_of_Desert+Quantity_of_Drinks;}
int Total_Amount(int Total_of_desert,int Total_of_fast,int Total_of_drinks ) {
	return Total_of_desert+ Total_of_fast + Total_of_drinks;}
	void cls(int burger_Q,int pizza_Q,int sandwich_Q,int donut_Q,int cupcake_Q,int Brownie_Q,int Soda_Q,int Juice_Q,int Coffee_Q){
	cout<<endl<<"////////////////////////////////////////////////////////////////"<<endl;
						cout<<" Your Seleccted Items are given below:-"<<endl<<endl;
						if(burger_Q>0) {
							cout<<" Quantity of Burger   = "<<burger_Q<<  "        Total of Burgers  = "<<burger_Q*200<<"Rs."<<endl;
						}
						if(pizza_Q>0) {
							cout<<" Quantity of Pizza    = "<<pizza_Q<<   "        Total of Pizza    = "<<pizza_Q*600<<"Rs."<<endl;
						}
						if(sandwich_Q>0) {
							cout<<" Quantity of Sandwich = "<<sandwich_Q<<"        Total of Sandwich = "<<sandwich_Q*250<<"Rs."<<endl;
						}
						if(donut_Q>0) {
							cout<<" Quantity of Donut    = "<<donut_Q<<   "        Total of Donut    = "<<donut_Q*80<<"Rs."<<endl;
						}
						if(cupcake_Q>0) {
							cout<<" Quantity of Cupcake  = "<<cupcake_Q<< "        Total of Cup.cake = "<<cupcake_Q*100<<"Rs."<<endl;
						}
						if(Brownie_Q>0) {
							cout<<" Quantity of Brownie  = "<<Brownie_Q<< "        Total of Brownie  = "<<Brownie_Q*150<<"Rs."<<endl;
						}
						if(Soda_Q>0) {
							cout<<" Quantity of Soda     = "<<Soda_Q<<    "        Total of Soda     = "<<Soda_Q*60<<"Rs."<<endl;
						}
						if(Juice_Q>0) {
							cout<<" Quantity of Juice    = "<<Juice_Q<<   "        Total of Juice    = "<<Juice_Q*80<<"Rs."<<endl;
						}
						if(Coffee_Q>0) {
							cout<<" Quantity of Coffee   = "<<Coffee_Q<<  "        Total of Coffee   = "<<Coffee_Q*120<<"Rs."<<endl;
						}
						cout<<"////////////////////////////////////////////////////////////////"<<endl;
}
//	        Main body
int main() {
	//decleration of variables for food quantity.
	int Quantity_of_Fast=0, Quantity_of_Desert=0, Quantity_of_Drinks=0 ;
	//decleration of variables for food category.
	int burger_Q=0, burger_Q2, pizza_Q=0,pizza_Q2,sandwich_Q2,donut_Q2=0,cupcake_Q2,Brownie_Q2,Soda_Q2,Juice_Q2,Coffee_Q2,GO,DESERT,DRINKS;
	int sandwich_Q=0, donut_Q=0, cupcake_Q=0, Brownie_Q=0, Soda_Q=0, Juice_Q=0, Coffee_Q=0  ;
	//decleration of variables for total of food type selected.
	int  Total_of_fast=0, Total_of_desert=0, Total_of_drinks=0,TOTAL_of_QUANTITY;
	//decleration of variables for total of food category.
	int  Total_of_Burger=0, Total_of_sandwich=0, Total_of_donut=0, Total_of_cupcake =0, Total_of_brownie=0 ;
	int  Total_of_Soda=0, Total_of_coffee=0, Total_of_Juice=0, Total_of_pizza=0;
	//decleration of variables for other functions.
	int  GRAND_TOTAL=0, whole_menu,end, ending, starts,Start;
	//decleration of variables for string functions.
	string fast, cart, Drinks, desert, food_type, card, start, confirm="yes", use, loop="enter",press="9";
	
	cout<<endl<<"\t\t\t\t\t   ------------------------";
	cout<<endl<<"\t\t\t\t\t   WELCOME TO OUR RESTURANT "<<endl;							//WELCOME FOR USER.
	cout<<      "\t\t\t\t\t   ------------------------"<<endl<<endl;
	cout<<endl<<" Do you want to Start order? (yes/no) : ";									//ORDER QUESTION FOR USER.
	cin>>start;cout<<endl;
	if(start=="yes"||start=="Yes"||start=="Y"||start=="y"||start=="START"||start=="Start"||start=="start"||start=="YES") {
		cout<<endl<<"\t\t\t\t\t  --------------------------";
		cout<<endl<<"\t\t\t\t\t  Here's the Restaurant Menu"<<endl;						//DISPLAY OF MENU.
		cout<<      "\t\t\t\t\t  --------------------------"<<endl;
Start:
		if (press=="0") {
			if(cart=="yes"||cart=="YES"||cart=="Yes"||cart=="Y"||cart=="y") {
				system("cls");
				cout<<endl<<"\t\t\t\t\t       --------------";
				cout<<endl<<"\t\t\t\t\t          Your CART   ";							//CART OF ITEMS USER HAS SELECTED. 
				cout<<endl<<"\t\t\t\t\t       --------------"<<endl<<endl;
				if(fast=="BURGER"||fast=="burger"||fast=="Burger"||fast=="PIZZA"||fast=="pizza"||fast=="Pizza"||fast=="SANDWICH"||fast=="sandwich"||fast=="Sandwich") {
					cout<<"-----------------------------------------------"<<endl;
					cout<<" Your Items form FAST FOOD type are given below "<<endl<<endl;
					//DISPLAY OF CART items saved 
					if(burger_Q>0) {
						cout<<" -> Quantity of Burger= "<<burger_Q<<endl;
					}
					if(pizza_Q>0) {
						cout<<" -> Quantity of Pizza= "<<pizza_Q<<endl;					
					}
					if(sandwich_Q>0) {
						cout<<" -> Quantity of Sandwich= "<<sandwich_Q<<endl;
					}
				}
				if(desert=="DONUT"||desert=="donut"||desert=="Donut"||desert=="CUP.CAKE"||desert=="cup.cake"||desert=="Cup.Cake"||desert=="BROWNIE"||desert=="brownie"||desert=="Brownie") {
					cout<<"-----------------------------------------------"<<endl;
					cout<<" Your Items form DESSERT type are given below "<<endl<<endl;
					if(donut_Q>0) {
						cout<<" -> Quantity of Donut= "<<donut_Q<<endl;
					}
					if(cupcake_Q>0) {
						cout<<" -> Quantity of Cupcake= "<<cupcake_Q<<endl;
					}
					if(Brownie_Q>0) {
						cout<<" -> Quantity of Brownie= "<<Brownie_Q<<endl;
					}
				}
				if(Drinks=="soda"||Drinks=="Soda"||Drinks=="SODA"||Drinks=="juice"||Drinks=="JUICE"||Drinks=="Juice"||Drinks=="COFFEE"||Drinks=="Coffee"||Drinks=="coffee") {
					cout<<"-----------------------------------------------"<<endl;
					cout<<" Your Items from DRINK type are given below "<<endl<<endl;
					if(Soda_Q>0) {
						cout<<" -> Quantity of Soda= "<<Soda_Q<<endl;
					}
					if(Juice_Q>0) {
						cout<<" -> Quantity of Juice= "<<Juice_Q<<endl;
					}
					if(Coffee_Q>0) {
						cout<<" -> Quantity of Coffee= "<<Coffee_Q<<endl;
					}
				}			//DISPLAY OF TOTAL CART ITEMS QUANTITY AND AMOUNT.
				cout<<"----------------------------------------------"<<endl;
				cout<<" Total Quantity of food items in cart = "<< Quantity_of_Desert + Quantity_of_Fast + Quantity_of_Drinks<<endl;
				cout<<" Total Amount is "<<Total_of_desert + Total_of_fast + Total_of_drinks<<"Rs."<<endl;
				cout<<"----------------------------------------------"<<endl;
				cout<<endl<<" Do you want to use saved cart?(yes/no) : ";		//IF USER TYPES (NO) THEN IT WILL START A NEW ORDER.
				cin>>use;
				if(use=="yes"||use=="YES"||use=="Yes"||use=="Y"||use=="y") {
					goto Line_462;
				} else {
					goto Again_start;
				}
			} else {

Again_start:
				system("cls");
				burger_Q=0,pizza_Q=0,donut_Q=0;
				cupcake_Q=0,Brownie_Q=0,Soda_Q=0;
				Juice_Q=0,Coffee_Q=0,Quantity_of_Fast=0,Quantity_of_Desert=0,Quantity_of_Drinks=0;
				Total_of_desert=0,Total_of_fast=0,Total_of_drinks=0,GRAND_TOTAL=0;
				cout<<endl<<"\t\t\t\t\t    ----------------------- ";
				cout<<endl<<"\t\t\t\t\t    PREVIOUS ORDER CANCELED ";					//WORKS WHEN THE USER DISMANTLE'S HIS/HER SAVED CART.
				cout<<endl<<"\t\t\t\t\t    ----------------------- "<<endl<<endl;
				cout<<endl<<" DO YOU WANT TO START NEW ORDER? : ";					//PROMPTS THE USER TO START NEW ORDER(IN CASE OF NOT SAVING CART).
				cin>>loop;
				if(loop=="yes"||loop=="Yes"||loop=="Y"||loop=="y"||loop=="YES") {
					system("cls");
				} else {
					goto ending;
				}
			}
		}
		for(; loop=="yes"||loop=="enter"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes";) {
whole_menu:

			if(Quantity_of_Fast>0||Quantity_of_Desert>0||Quantity_of_Drinks>0) {
				system("cls");
				cls(burger_Q,pizza_Q, sandwich_Q, donut_Q, cupcake_Q, Brownie_Q, Soda_Q, Juice_Q, Coffee_Q);
			}
								//OUR RESTAURANT MENU (SELECTION OF ANY ONE FROM THEM)
			again_food_type:
			cout<<endl<<" -> For FAST FOOD  (Press 1)"<<endl<<" -> For DESSERT    (Press 2)"<<endl<<" -> For DRINKS     (Press 3) "<<endl;
			cout<<endl<<" Choose any one from above : ";
			cin>>food_type;
			system("cls");
			if(food_type=="1") {														
				for(; food_type=="1"||food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes";) {
fast_type:
					system("cls");
					if(Quantity_of_Fast>0||Quantity_of_Desert>0||Quantity_of_Drinks>0) {
	 						cls(burger_Q,pizza_Q, sandwich_Q, donut_Q, cupcake_Q, Brownie_Q, Soda_Q, Juice_Q, Coffee_Q);
					}
					if(food_type=="NO"||food_type=="no"||food_type=="No"||food_type=="N"||food_type=="n") {
						goto T_of_fast;
					}				//DISPLAY OF FAST FOOD ITEMS
					cout<<endl<<"\t\t\t\t\t       ---------------";
				    cout<<endl<<"\t\t\t\t\t          FAST FOOD   ";
					cout<<endl<<"\t\t\t\t\t       ---------------"<<endl<<endl;	
fast:				
					cout<<" -> BURGER"<<endl<<" -> PIZZA"<<endl<<" -> SANDWICH "<<endl;				//SELECTION OF ANY ONE OF THEM.
					cout<<endl<<" Type (name) of any of above you want : ";					
					cin>>fast;
					cout<<endl;
					if(fast=="burger"||fast=="Burger"||fast=="BURGER") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one burger is 200Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") {
							cout<<" Enter the Quantity : ";
							cin>>burger_Q2;
							burger_Q+=burger_Q2;
							cout<<" Price of "<< burger_Q << " Burger will be "<<burger_Q*200<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;						
						}
						if(food_type=="1"&&confirm=="yes"&&loop=="enter") {
							cout<<" Enter the Quantity of Burger: ";									
							cin>>burger_Q;
							cout<<" Price of "<< burger_Q << " Burger will be "<<burger_Q*200<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;					
						}
						Total_of_Burger=+burger_Q*200;
						cout<<endl<<" Anything else from this MENU?(yes/no) : ";			//ANYTHING ELSE INCLUDING BURGER FROM FAST FOOD.
					} 
					else if(fast=="pizza"||fast=="Pizza"||fast=="PIZZA") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one pizza is 600 Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") {
							cout<<" Enter the Quantity : ";
							cin>>pizza_Q2;
							pizza_Q+=pizza_Q2;
							cout<<" Price of "<< pizza_Q << " Pizza will be "<<pizza_Q*600<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						if(food_type=="1"&&confirm=="yes"&&loop=="enter") {
							cout<<" Enter the Quantity of Pizza : ";
							cin>>pizza_Q;
							cout<<" Price of "<< pizza_Q << " Pizza will be "<<pizza_Q*600<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_pizza=+pizza_Q*600;
						cout<<endl<<" Anything else from this MENU?(yes/no) : ";				//ANYTHING ELSE INCLUDING PIZZA FROM FAST FOOD.
					}
					else if(fast=="sandwich"||fast=="Sandwich"||fast=="SANDWICH") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one sandwich is 250Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") {
							cout<<" Enter the Quantity : ";
							cin>>sandwich_Q2;
							sandwich_Q+=sandwich_Q2;
							cout<<" Price of "<<sandwich_Q<<" Sandwich will be "<<sandwich_Q*250<<"Rs. "<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						if(	food_type=="1"&&confirm=="yes"&&loop=="enter") {		
							cout<<" Enter the Quantity of Sandwich : ";
							cin>>sandwich_Q;
							cout<<" Price of "<<sandwich_Q<<" Sandwich will be "<<sandwich_Q*250<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_sandwich=+sandwich_Q*250;
						cout<<endl<<" Anything else form this MENU?(yes/no) : ";				//ANYTHING ELSE INCLUDING SANDWICH FROM FAST FOOD.
					}
					else {
						cout<<"----------------------------------"<<endl;				//WORKS WHEN USER TYPES WRONG WORD
						cout<<" You have entered wrong Item(name)"<<endl;				//                               FROM FAST MENU.
						cout<<" Re-enter the item "<<endl;
						cout<<"----------------------------------"<<endl<<endl;
						goto fast;
					}
					cin>>food_type;
					Quantity_of_Fast=burger_Q + pizza_Q + sandwich_Q;
					if(food_type=="NO"||food_type=="no"||food_type=="No"||food_type=="N"||food_type=="n") {				
						goto fast_type;				
					}
				}
T_of_fast:
				Total_of_fast=Total_of_Burger + Total_of_pizza + Total_of_sandwich;
				Quantity_of_Fast=burger_Q + pizza_Q + sandwich_Q;
				cout<<endl<<"---------------------------------------";
				cout<<endl<<" Quantity of FAST FOOD items is "<<Quantity_of_Fast<<endl<<endl;		//DISPLAY OF QUANTITY AND AMOUNT 
				cout<<      " Total bill of only FAST FOOD = "<<Total_of_fast<<"Rs."<<endl;			//               OF ONLY FAST FOOD.
				cout<<      "---------------------------------------"<<endl;
			} 
			else if(food_type=="2") {
				for(; food_type=="2"||food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes";) {
desert_type:
					system("cls");
					if(Quantity_of_Fast>0||Quantity_of_Desert>0||Quantity_of_Drinks>0) {
						cls(burger_Q,pizza_Q, sandwich_Q, donut_Q, cupcake_Q, Brownie_Q, Soda_Q, Juice_Q, Coffee_Q);
						if(food_type=="no"||food_type=="NO"||food_type=="No"||food_type=="N"||food_type=="n") {
							goto T_of_desert;
						}
					}				//DISPLAY OF DESERT ITEMS	
					cout<<endl<<"\t\t\t\t\t       --------------";
				    cout<<endl<<"\t\t\t\t\t           DESSERT    ";
					cout<<endl<<"\t\t\t\t\t       --------------"<<endl<<endl;
DESERT:
					cout<<" -> DONUT"<<endl<<" -> CUP.CAKE"<<endl<<" -> BROWNIE"<<endl;					//SELECTION OF ANY ONE OF THEM.
					cout<<endl<<" Type (name) of any of above you want : ";
					cin>>desert;
					cout<<endl;
					if(desert=="Donut"||desert=="donut"||desert=="DONUT") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one Donut is 80Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||loop=="yes"||confirm=="add"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") { 
							cout<<" Enter the Quantity : "  ;
							cin>>donut_Q2;
							donut_Q+=donut_Q2;
							cout<<" Price of "<<donut_Q <<" Donut will be "<<donut_Q*80<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						if(	food_type=="2"&&confirm=="yes"&&loop=="enter") {		
							cout<<" Enter the Quantity of Donut : ";
							cin>>donut_Q;;
							cout<<" Price of "<<donut_Q <<" Donut will be "<<donut_Q*80<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_donut=+donut_Q*80;
						cout<<endl<<" Anything else from this MENU? (yes/no) : ";						//ANYTHING ELSE INCLUDING DONUT FROM DESERT.
					} 
					else if(desert=="Cup.Cake"||desert=="cup.cake"||desert=="CUP.CAKE") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one cup.cake is 100Rs."<<endl;
						if(loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes"||food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes") {
							cout<<" Enter the Quantity : "  ;
							cin>>cupcake_Q2;
							cupcake_Q+=cupcake_Q2;
							cout<<" Price of "<<cupcake_Q<<" cup.cake will be "<<cupcake_Q*100<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						if(	food_type=="2"&&confirm=="yes"&&loop=="enter") {
							cout<<" Enter the Quantity of cup.cake : ";
							cin>>cupcake_Q;
							cout<<" Price of "<<cupcake_Q<<" cup.cake will be "<<cupcake_Q*100<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_cupcake=+cupcake_Q*100;
						cout<<endl<<" Anything else from this MENU? (yes/no) : ";						//ANYTHING ELSE INCLUDING CUP.CAKE FROM DESERT.
					} 
					else if(desert=="Brownie"||desert=="brownie"||desert=="BROWNIE") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one Brownie = 150 Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") {
							cout<<" Enter the Quantity : "  ;
							cin>>Brownie_Q2;
							Brownie_Q+=Brownie_Q2;
							cout<<" Price of "<< Brownie_Q <<" Brownie will be "<< Brownie_Q * 150<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						if(food_type=="2"&&confirm=="yes"&&loop=="enter") {
							cout<<" Enter the Quantity of Brownie: ";
							cin>>Brownie_Q;
							cout<<" Price of "<< Brownie_Q <<" Brownie will be "<< Brownie_Q * 150<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_brownie = + Brownie_Q * 150;
						cout<<endl<<" Anything else from this MENU? (yes/no) : ";						//ANYTHING ELSE INCLUDING BROWNIE FROM DESERT.
					}
					 else {
						cout<<"----------------------------------"<<endl;
						cout<<" You have entered wrong Item(name)"<<endl;								//WORKS WHEN USER TYPES WRONG WORD
						cout<<" Re-enter the item "<<endl;																	//FROM DESERT SECTION.
						cout<<"----------------------------------"<<endl<<endl;
						goto DESERT;
					}
					cin>>food_type;
					Quantity_of_Desert= donut_Q + cupcake_Q + Brownie_Q;
					if(food_type=="no"||food_type=="NO"||food_type=="No"||food_type=="N"||food_type=="n") {
						goto desert_type;
					}
				}
T_of_desert:
				Total_of_desert = Total_of_donut + Total_of_cupcake + Total_of_brownie;
				Quantity_of_Desert= donut_Q + cupcake_Q + Brownie_Q;
				cout<<endl<<"-------------------------------------";
				cout<<endl<<" Quantity of DESSERT items is "<<Quantity_of_Desert<<endl<<endl;			//DISPLAY OF QUANTITY AND AMOUNT
				cout<<      " Total bill of only DESSERT = "<<Total_of_desert<<"Rs."<<endl;				//               		 OF DESERT ITEMS ONLY.
				cout<<      "-------------------------------------"<<endl;	
			} 
			else if(food_type=="3") {
				for(; food_type=="3"||food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes";) {
drinks_type:
					system("cls");
					if(Quantity_of_Fast>0||Quantity_of_Desert>0||Quantity_of_Drinks>0) {
							cls(burger_Q,pizza_Q, sandwich_Q, donut_Q, cupcake_Q, Brownie_Q, Soda_Q, Juice_Q, Coffee_Q);
						if(food_type=="no"||food_type=="NO"||food_type=="No"||food_type=="N"||food_type=="n") {
							goto  T_of_drinks;
						}
					}		
										//DISPLAY OF DRINKS ITEMS
					cout<<endl<<"\t\t\t\t\t       ---------------";
				    cout<<endl<<"\t\t\t\t\t            DRINKS    ";
					cout<<endl<<"\t\t\t\t\t       ---------------"<<endl<<endl;
DRINKS:
					cout<<" -> SODA"<<endl<<" -> JUICE"<<endl<<" -> COFFEE"<<endl;					//SELECTION OF ANY ONE OF THEM.
					cout<<endl<<" Type (name) of any of above you want : ";
					cin>>Drinks;
					cout<<endl;
					if(Drinks=="soda"||Drinks=="Soda"||Drinks=="SODA") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one Soda is 60Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") {
							cout<<" Enter the quantity : "  ;
							cin>>Soda_Q2;
							Soda_Q+=Soda_Q2;
							cout<<" Price of "<<Soda_Q<<" Soda will be "<<Soda_Q*60<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						if(	food_type=="3"&&confirm=="yes"&&loop=="enter") {
							cout<<" Enter the Quantity of Soda : ";
							cin>>Soda_Q;
							cout<<" Price of "<<Soda_Q<<" Soda will be "<<Soda_Q*60<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_Soda=+Soda_Q*60;
						cout<<endl<<" Anything else form this MENU? (yes/no) :";					//ANYTHING ELSE INCLUDING SODA FROM DRINKS.
					} 
					else if(Drinks=="juice"||Drinks=="Juice"||Drinks=="JUICE") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one Juice is 80Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") {
							cout<<" Enter the Quantity : "  ;
							cin>>Juice_Q2;
							Juice_Q+=Juice_Q2;
							cout<<" Price of "<<Juice_Q<<" Juice will be "<<Juice_Q*80<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}

						if(	food_type=="3"&&confirm=="yes"&&loop=="enter") {
							cout<<" Enter the Quantity of Juice : ";
							cin>>Juice_Q;
							cout<<" Price of "<<Juice_Q<<" Juice will be "<<Juice_Q*80<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_Juice=+Juice_Q*80;
						cout<<endl<<" Anything else from this MENU? (yes/no) : ";					//ANYTHING ELSE INCLUDING JUICE FROM DRINKS.
					} 
					else if(Drinks=="coffee"||Drinks=="COFFEE"||Drinks=="Coffee") {
						cout<<"-------------------------------------"<<endl;
						cout<<" Price of one Coffee is 120Rs."<<endl;
						if(food_type=="yes"||food_type=="Y"||food_type=="y"||food_type=="YES"||food_type=="Yes"||confirm=="add"||loop=="yes"||loop=="YES"||loop=="Y"||loop=="y"||loop=="Yes") {
							cout<<" Enter the Quantity : "  ;
							cin>>Coffee_Q2;
							Coffee_Q+=Coffee_Q2;
							cout<<" Price of "<<Coffee_Q<<" Coffee will be "<<Coffee_Q*120<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}

						if(	food_type=="3"&&confirm=="yes"&&loop=="enter") {
							cout<<" Enter the Quantity of Coffee: ";
							cin>>Coffee_Q;
							cout<<" Price of "<<Coffee_Q<<" Coffee will be "<<Coffee_Q*120<<"Rs."<<endl;
							cout<<"-------------------------------------"<<endl;
						}
						Total_of_coffee=+Coffee_Q*120;
						cout<<endl<<" Anything else form this MENU? (yes/no) : ";					//ANYTHING ELSE INCLUDING COFFEE FROM DRINKS.
					} else {
						cout<<"----------------------------------"<<endl;
						cout<<" You have entered wrong Item(name)"<<endl;							//WORKS WHEN USER TYPES WRONG WORD
						cout<<" Re-enter the item "<<endl;											// 								FROM DRINKS SECTION.
						cout<<"----------------------------------"<<endl<<endl;
						goto DRINKS;
					}
					cin>>food_type;
					Quantity_of_Drinks=Soda_Q + Juice_Q + Coffee_Q;
					if(food_type=="no"||food_type=="NO"||food_type=="No"||food_type=="N"||food_type=="n") {
						goto drinks_type;
					}
				}
T_of_drinks:
				Quantity_of_Drinks=Soda_Q + Juice_Q + Coffee_Q;
				Total_of_drinks=Total_of_Soda + Total_of_Juice + Total_of_coffee;
				cout<<endl<<"-------------------------------------";
				cout<<endl<<" Quantity of DRINKS is "<<Quantity_of_Drinks<<endl<<endl;				//DISPLAY OF QUANTITY AND AMOUNT 
				cout<<      " Total bill of only DRINKS = "<<Total_of_drinks<<"Rs."<<endl;			//					OF ONLY DRINKS.
				cout<<      "-------------------------------------"<<endl;
			} 
			else {
				cout<<endl<<" \t\t\t\t\t       ---------------"<<endl;									//WORKS WHEN USER TYPES INVALID NUMBER
				cout<<      " \t\t\t\t\t         ERROR FOUND  "<<endl;									//		    FROM THE RESTAURANT MENU(FOOD=1,DESERT=2,DRINKS=3)
				cout<<      " \t\t\t\t\t       ---------------"<<endl<<endl;
				cout<<endl<<"-------------------------";
				cout<<endl<<" "<<food_type<<" is an invalid number. "<<endl<<endl;
				cout<<" You are given a chance to Re-select the FOOD TYPE from MENU.";				//RE-SELECTION OF FOOD TYPE FROM MENU.
				cout<<endl<<"-------------------------------------------------------------"<<endl;
				goto again_food_type;
			}
			cout<<endl<<" Do you want to order from the WHOLE MENU?(yes/no) : ";					//IN CASE OF MORE ITEMS FROM DIFFERENT FOOD TYPE.
			cin>>loop;
		}
Line_462:
		system("cls");
		if(Quantity_of_Fast>0||Quantity_of_Desert>0||Quantity_of_Drinks>0) {
				cls(burger_Q,pizza_Q, sandwich_Q, donut_Q, cupcake_Q, Brownie_Q, Soda_Q, Juice_Q, Coffee_Q);
		}
		system("cls");cout<<endl;
		cout<<"-----------------------------------------------"<<endl;											
		cout<<" TOTAL QUANTITY= "<<total_quantity(Quantity_of_Fast,Quantity_of_Desert,Quantity_of_Drinks)<<endl;	//TOTAL QUANTITY OF ALL FOOD ITEMS SELECTED.
		cout<<" GRAND TOTAL= "<<Total_Amount( Total_of_desert, Total_of_fast, Total_of_drinks )<<endl;				//TOTAL AMOUNT OF ALL FOOD ITEMS.
		cout<<"-----------------------------------------------"<<endl;
		cout<<endl<<"\t\t\t\t\t      -------------------";
		cout<<endl<<"\t\t\t\t\t          R E V I E W     "<<endl;														// DECISION BY USER
		cout<<      "\t\t\t\t\t      -------------------"<<endl<<endl;
		process_cancel:																	//IN ORDER TO 
		cout<<"  -> Want to Process Order (Press 1)"<<endl<<endl<<"  -> Want to Cancel order (press 0) "<<endl<<endl;							//CANCEL OR PROCEESS ORDER.
		cout<<"     Type : ";			//??????????????????????????????????
		cin>>press;
		if(press=="0") {
			cout<<endl<<endl<<" Do you want to save this order to CART?(yes/no) : ";
			cin>>cart;						//CART SAVING & DIMANTLING OPTION
			goto Start;									//IF IT IS (YES) THEN SHOWS THE SAVED CART. 
		}										//IF IT IS (NO) THEN CANCELS THE PREVIOUS ORDER AND WILL START A NEW ONE.		
		else if(press=="1"){ 
		system("cls");
		cout<<endl<<"\t\t\t\t\t      ------------------";
		cout<<endl<<"\t\t\t\t\t      ORDER CONFIRMATION ";				//A CONFIRMATION MESSAGE.
		cout<<endl<<"\t\t\t\t\t      ------------------"<<endl<<endl;			//IF IT IS (YES) THEN WILL GO TO PAYMENT SITE.			
		cout<<"  -> If confirmed type(yes) "<<endl<<endl<<"  -> If you want to add something else type(add) "<<endl<<endl;
		cout<<"     Type : ";												//IF IT IS (NO) THEN USER CAN ADD-UP MORE THINGS.
		cin>>confirm;
		}else{
			system("cls");
		cout<<endl<<"\t\t\t\t       ----------------------------------------------";
		cout<<endl<<"\t\t\t\t       YOU ENTERED WRONG NO: PLZ SELECT BETWEEN (0/1)";
		cout<<endl<<"\t\t\t\t       ----------------------------------------------"<<endl<<endl;
		goto process_cancel;
		}
		if(confirm=="yes"||confirm=="Y"||confirm=="y"||confirm=="Yes"||confirm=="YES") {
			system("cls");
			cout<<" "<<endl;
			cout<<"-----------------------------------------------"<<endl;
			cout<<" TOTAL QUANTITY= "<<total_quantity(Quantity_of_Fast,Quantity_of_Desert,Quantity_of_Drinks)<<endl;		//TOTAL QUANTITY OF ALL FOOD ITEMS SELECTED(ON PAYMENT SITE).
			cout<<" GRAND TOTAL= "<<Total_Amount( Total_of_desert, Total_of_fast, Total_of_drinks )<<endl;					//TOTAL AMOUNT OF ALL FOOD ITEMS SELECTED(ON PAYMENT SITE).
			cout<<"-----------------------------------------------"<<endl;
			GRAND_TOTAL=Total_Amount( Total_of_desert, Total_of_fast, Total_of_drinks );
payment :
			cout<<endl<<"\t\t\t\t\t      ---------------";
			cout<<endl<<"\t\t\t\t\t      PAYMENT METHODS "<<endl;																//PAYMENT METHODS
		    cout<<      "\t\t\t\t\t      ---------------"<<endl<<endl;
			cout<<endl<<" -> For card Payment (Type card)=>(10% DISCOUNT) "<<endl<<endl;										//CARD & CASH
			cout<<" -> Through cash Payment (Type cash)=>(NO DISCOUNT) "<<endl<<endl;						
			cout<<"    Type = ";cin >>card;
			if(card=="card"||card=="Card"||card=="CARD") {
				system("cls");
				cout<<endl<<"--------------------------------------------------"<<endl;			
				cout<<" Discount on total "<<GRAND_TOTAL<<" Rs. using card is = "<< 0.1 * GRAND_TOTAL <<" Rs."<<endl<<endl;	
				cout<<" Now the total amount to pay is "<<GRAND_TOTAL-(0.1*GRAND_TOTAL)<<" Rs."<<endl;	//10% DISCOUNT ON CARD.
			    cout<<endl<<"\t\t\t\t\t      -------------------";
				cout<<endl<<"\t\t\t\t\t      THANKS FOR VISITING"<<endl;					//PROGRAM ENDS AFTER PAYING THROUGH CARD.
				cout<<		"\t\t\t\t\t      -------------------"<<endl<<endl;
				cout<<"--------------------------------------------------"<<endl;
			} else if(card=="cash"||card=="CASH"||card=="Cash") {
				system("cls");
				cout<<endl<<"-----------------------------------------------"<<endl;
				cout<<" No discount on cash. "<<endl<<endl;
				cout<<" So GRAND total is "<<GRAND_TOTAL<<" Rs."<<endl;				//NO DISCOUNT ON CASH.
				cout<<endl<<"\t\t\t\t      -------------------";
				cout<<endl<<"\t\t\t\t      THANKS FOR VISITING"<<endl;	//PROGRAM ENDS AFTER PAYING THROUGH CASH.
				cout<<      "\t\t\t\t      -------------------"<<endl<<endl;
				cout<<"-----------------------------------------------"<<endl;
			}else{
				system("cls");
				cout<<endl<<"-----------------------------------------------"<<endl;
				cout<<" You have entered wrong Payment method "<<endl;				
				cout<<" Try correct this time "<<endl;						  //IN CASE OF WRONG WORD USED. 
				cout<<"-----------------------------------------------"<<endl;
				goto payment;		//IT WILL AUTOMATICALLY MOVE U TO THE PAYMENT SITE.
			}
		} else {
			goto whole_menu;
		}
	} else {
ending:
		cout<<"-------------------------------------------------------"<<endl;
		cout<<endl<<" MENU CLOSED RESTART THE PROGRAM AND TYPE YES TO ORDER. "<<endl<<endl;
		cout<<endl<<"\t\t\t\t\t      -------------------";						//WHEN USER DON'T WANT TO ORDER ANYTHING FROM THE RESTAURANT MENU PAGE.
		cout<<endl<<"\t\t\t\t\t            THANKS      "<<endl;
		cout<<      "\t\t\t\t\t      -------------------"<<endl;
	}
}