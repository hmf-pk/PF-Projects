#include<iostream>
#include<cstdlib>       //for rand(); and srand();
#include<ctime>        //for time(0);
#include<windows.h>    //for system("cls");
int u=0,c=0,mp=0;  //userscore,computer score and matchplayed variables initialization
using namespace std;
void compChoice( int com);
void userChoice(int choice);
void displayOptions ();
void checkWin(int com,int choice);
 
int main ()
{     char play;
    srand(time(0));//generate seed value for rand(); function and time(0); for taking comp time   
    int choice;
    do    //do while loop for taking user choice(input)
    {
     displayOptions ();
     cout<<"ENTER YOUR CHOICE !   ";
     cin>>choice;
	 system("cls");     //for clearing screen
	if(choice>0&&choice<4){   // if for user input validation 
	
     int com = rand()%3+1;// rand(); for taking computer choice 
     cout<<"============================================\n\n";
     userChoice( choice);
     compChoice(com );
     cout<<"=============================================\n\n";
       checkWin( com, choice);
       cout<<"=============================================\n\n";
     cout<<"\n PLAY AGAIN (y/n) :"<<endl;
	 cin>>play;
	 system("cls");
	 
	  if(play=='n')
	 cout<<"THANKS FOR PLAYING\n\n ";
	   if(play!='y'&&play!='n')
	   cout<<"INVALID MOVE !";
	   
}
else
{
cout<<"INVALID MOVE ! ";
break; }
}
	 
	 while(play=='y');
	 if(play=='n'){  //table for score and matchplayed which will show at the end 
	 	
	 	cout<<"        ===================SCORE AND MATCHPLAYED===========================\n";
	 	
	 	cout<<"                    |MATCH     PLAYED     ARE "<<mp<<"|\n";
	    cout<<"                    |                          |"<<endl;
	 	cout<<"                    |USER      SCORE     IS   "<<u<<"|"<<endl;
	 	cout<<"                    |                          |"<<endl;
	 	cout<<"                    |COMPUTER    SCORE     IS "<<c<<"|\n";
	 	cout<<"       =====================================================================";
	 	
	 }
	 
return 0;
}

 void displayOptions ()
{    cout<<"--------(ROCK PAPER SCISSORS)-----------\n ";
	cout<<"       SELECT AN OPTION :"<<endl;
	cout<<" 1.rock "<<endl;
	cout<<" 2. paper"<<endl;
	cout<<" 3. scissors"<<endl;	
}

   void userChoice(int choice){
   	  if( choice==1){
   	  	cout<<" your choice is rock :";}
   	  else	if( choice==2){
   	  	cout<<" your choice is paper :";}
   	  	if( choice==3){
   	  	cout<<" your choice is scissors :";


		 } 
   }
   
       void compChoice(int com){
     
	   if(com==1)
	   cout<<"computer choice is rock\n";
	   else if(com ==2)
	   cout<<" computer choice is paper\n";
	   else if (com==3)
	   cout<<" computer choice is scissors\n"; 	
	   }
	   // checkwin function 
//	   increase value of u if user won 
//  increase value of c if comp won 
// mp (matchplayed) will be incremented if any of them won 
     void checkWin(int com,int choice){  
     	if(com==choice)
   		cout<<" it's a tie! \n";
     	else if(com==1&&choice==2){
		 
		 cout<<" user wins ! \n " ;
		 u+=1;}
		 else if(com==1&&choice==3){
		 
		 cout<<" computer wins \n";
		 c+=1;}
		 else if(com==2&&choice==1){
		 
		 cout<<" computer wins \n ";c+=1;}
		 else if(com==2&&choice==3){
		 
		 cout<<"user wins ! \n " ;
		 u+=1;}
		 else if (com== 3&& choice==2 ){
		 
		 cout<<"computer wins \n "; c+=1;}
		 else {
		 
		 cout<<"user won \n" ;
		 u+=1;}
		 mp+=1;
	 }




