#include <iostream>
#include<cstdlib>

using namespace std;

void showOrderDetails(const string items[], const unsigned int prices[], int choices[], int numItems) {
    cout << "Order Details:\n";
    for (int i = 0; i < numItems; ++i) {
        cout << items[choices[i] - 1] << " - Rs " << prices[choices[i] - 1] << endl;
    }
}

int main() {
    const int NUM_ITEMS = 10;
    unsigned int prices[NUM_ITEMS] = {599, 750, 825, 999, 450, 375, 649, 299, 525, 400};
    string items[NUM_ITEMS] = {"Burger", "Pizza", "Pasta", "Steak", "Salad", "Soup", "Sandwich", "Fries", "Chicken", "Ice Cream"};

    unsigned int totalBill = 0.0;
    char orderAgain;

    int choices[NUM_ITEMS]; // Array to store user choices

    int numItemsOrdered = 0; // Counter to keep track of the number of items ordered

    do {
        // Display menu
        cout << "Menu:\n";
        for (int i = 0; i < NUM_ITEMS; ++i) {
            cout << i + 1 << ". " << left << items[i] << " - Rs " << prices[i] << endl;
        }

        // Get user input
        int choice;
        cout << "Enter the number of the item you want to order (1-10): ";
        cin >> choice;

        if (choice >= 1 && choice <= NUM_ITEMS) {
            choices[numItemsOrdered] = choice; // Store user choice
            totalBill += prices[choice - 1];
            cout << items[choice - 1] << " added to your order.\n";
            numItemsOrdered++;
        } else {
            cout << "Invalid choice. Please enter a number between 1 and 10.\n";
        }

        // Ask if user wants to order something else
        cout << "Do you want to order something else? (y/n): ";
        cin >> orderAgain;
    } while (orderAgain == 'y' || orderAgain == 'Y');

    // Display order details
    showOrderDetails(items, prices, choices, numItemsOrdered);

    // Display total bill
    cout << "Your total bill is: Rs " << totalBill << endl;

    // Get amount paid by the customer
    unsigned int amountPaid;
    cout << "Enter the amount you are handing over: Rs ";
    cin >> amountPaid;

    // Calculate and display change
    unsigned int change = amountPaid - totalBill;
    cout << "Your change is: Rs " << change << endl;

    // Ask whether the customer wants to dine in or take away
    char dineInOrTakeAway;
    cout << "Do you want to dine in or take away? (D/T): ";
    cin >> dineInOrTakeAway;

    if (dineInOrTakeAway == 'D' || dineInOrTakeAway == 'd') {
        // Assign a table and ask the customer to wait
        int tableNumber = rand() % 10 + 1; // Assign a random table number between 1 and 10
        cout << "Please wait at table number " << tableNumber << ". Your order will be served shortly.\n";
    } else if (dineInOrTakeAway == 'T' || dineInOrTakeAway == 't') {
        // Assign a take-away booth and ask the customer to wait
        int boothNumber = rand() % 5 + 1; // Assign a random booth number between 1 and 5
        cout << "Please wait at take-away booth number " << boothNumber << ". Your order will be ready soon.\n";
    } else {
        cout << "Invalid choice for dine in or take away.\n";
    }

    return 0;
}
