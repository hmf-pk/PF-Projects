
#include <iostream>
#include <cmath>
#include <fstream>
#include <limits>
using namespace std;

int main() {
    ofstream outFile("calculator_log.txt", ios::app); // Open file for appending

    // Display program header
    outFile << "\t\n";
    outFile << "\t____________________________________________\n";
    outFile << "\t           SCIENTIFIC CALCULATOR\n";
    outFile << "\t--------------------------------------------\n";
    outFile << "\t \n";

    // Display menu options
    outFile << "\t1: Addition\t\t11: Sin\n";
    outFile << "\t2: Subtraction\t\t12: Cos\n";
    outFile << "\t3: Multiplication\t13: Tan\n";
    outFile << "\t4: Division\t\t14: Inverse Sin\n";
    outFile << "\t5: Exponent\t\t15: Inverse Cos\n";
    outFile << "\t6: Square\t\t16: Inverse Tan\n";
    outFile << "\t7: Log\t\t\t17: Factorial\n";
    outFile << "\t8: Reciprocal\t\t18: Degrees to Radians\n";
    outFile << "\t9: Natural Logarithm\t19: Base 10 Logarithm\n";
    outFile << "\t10: Power of E\t\t20: Average\n";
    outFile << "\t\t\t21: Exit\n";

    double x, y;
    int choice;

    // Main loop for user interaction
    do {
        // Prompt the user for the desired operation
        outFile << "\nEnter the number related to that function you want to perform: ";

        // Check if the input is a character
        if (cin >> choice) {
            if (choice >= 1 && choice <= 20) {
                switch (choice) {
                      // Addition operation
                    case 1:
                        cout << "Enter the first number: ";
                        cin >> x;
                        cout << "Enter the second number: ";
                        cin >> y;
                        cout << "\nRESULT: " << x + y << endl;
                        break;

                    // Subtraction operation
                    case 2:
                        cout << "Enter the first number: ";
                        cin >> x;
                        cout << "Enter the second number: ";
                        cin >> y;
                        cout << "\nRESULT: " << x - y << endl;
                        break;

                    // Multiplication operation
                    case 3:
                        cout << "Enter the first number: ";
                        cin >> x;
                        cout << "Enter the second number: ";
                        cin >> y;
                        cout << "\nRESULT: " << x * y << endl;
                        break;

                    // Division operation
                    case 4:
                        cout << "Enter the first number: ";
                        cin >> x;
                        cout << "Enter the second number: ";
                        cin >> y;
                        if (y != 0) {
                            cout << "\nRESULT: " << x / y << endl;
                        } else {
                            cout << "Error: Division by zero is undefined." << endl;
                        }
                        break;

                    // Exponentiation operation
                    case 5:
                        cout << "Enter the base: ";
                        cin >> x;
                        cout << "Enter the exponent: ";
                        cin >> y;
                        cout << "\nRESULT: " << pow(x, y) << endl;
                        break;

                    // Square root operation
                    case 6:
                        cout << "Enter the number: ";
                        cin >> x;
                        cout << "\nRESULT: " << sqrt(x) << endl;
                        break;


                    // Logarithm operation (Base 10)
                    case 7:
                        cout << "Enter the number: ";
                        cin >> x;
                        if (x <= 0) {
                            cout << "Error: Logarithm is undefined for non-positive numbers." << endl;
                        } else {
                            outFile << "\nRESULT: " << log10(x) << endl;
                        }
                        break;

                        // Reciprocal operation
                    case 8:
                        cout << "Enter the number: ";
                        cin >> x;
                        if (x != 0) {
                            cout << "\nRESULT: " << 1 / x << endl;
                        } else {
                            cout << "Error: Reciprocal of zero is undefined." << endl;
                        }
                        break;

                    // Natural Logarithm operation
                    case 9:
                        cout << "Enter the number: ";
                        cin >> x;
                        if (x <= 0) {
                            cout << "Error: Logarithm is undefined for non-positive numbers." << endl;
                        } else {
                            cout << "\nRESULT: " << log(x) << endl;
                        }
                        break;

                    // Power of E operation
                    case 10:
                        cout << "Enter the exponent: ";
                        cin >> x;
                        cout << "\nRESULT: " << exp(x) << endl;
                        break;

                    // Sine operation
                    case 11:
                        cout << "Enter the angle in degrees: ";
                        cin >> x;
                        cout << "\nRESULT: " << sin(x * M_PI / 180.0) << endl;
                        break;

                    // Cosine operation
                    case 12:
                        cout << "Enter the angle in degrees: ";
                        cin >> x;
                        cout << "\nRESULT: " << cos(x * M_PI / 180.0) << endl;
                        break;

                    // Tangent operation
                    case 13:
                        cout << "Enter the angle in degrees: ";
                        cin >> x;
                        cout << "\nRESULT: " << tan(x * M_PI / 180.0) << endl;
                        break;

                    // Inverse Sine operation
                    case 14:
                        cout << "Enter the value: ";
                        cin >> x;
                        if (x >= -1 && x <= 1) {
                            cout << "\nRESULT: " << asin(x) * 180.0 / M_PI << " degrees" << endl;
                        } else {
                            cout << "Error: Input value must be between -1 and 1 for inverse sine." << endl;
                        }
                        break;

                    // Inverse Cosine operation
                    case 15:
                        cout << "Enter the value: ";
                        cin >> x;
                        if (x >= -1 and x <= 1) {
                            cout << "\nRESULT: " << acos(x) * 180.0 / M_PI << " degrees" << endl;
                        } else {
                            cout << "Error: Input value must be between -1 and 1 for inverse cosine." << endl;
                        }
                        break;

                    // Inverse Tangent operation
                    case 16:
                        cout << "Enter the value: ";
                        cin >> x;
                        cout << "\nRESULT: " << atan(x) * 180.0 / M_PI << " degrees" << endl;
                        break;

                    // Factorial operation
                    case 17:
                        cout << "Enter the value: ";
                        cin >> x;
                        if (x < 0) {
                            cout << "Error: Factorial is not defined for negative numbers." << endl;
                        } else {
                            double result = 1;
                            for (int i = 1; i <= x; ++i) {
                                result *= i;
                            }
                            cout << "\nRESULT: " << result << endl;
                        }
                        break;

                    // Degrees to Radians conversion
                    case 18:
                        cout << "Enter the number in degrees: ";
                        cin >> x;
                        cout << "\nRESULT: " << x * M_PI / 180.0 << " radians" << endl;
                        break;

                    // Base 10 Logarithm operation
                    case 19:
                        cout << "Enter the number: ";
                        cin >> x;
                        if (x <= 0) {
                            cout << "Error: Logarithm is undefined for non-positive numbers." << endl;
                        } else {
                            cout << "\nRESULT: " << log10(x) << endl;
                        }
                        break;

                    // Average operation
                    case 20:
                        cout << "Enter the first number: ";
                        cin >> x;
                        cout << "Enter the second number: ";
                        cin >> y;
                        cout << "\nRESULT: " << (x + y) / 2 << endl;
                        break;

                    // Exit the program
                    case 21:
                        outFile << "Thank you for using the calculator. Have a great day! :)\n";
                        break;

                    // Invalid choice
                    default:
                        outFile << "Invalid choice. Please enter a correct choice.\n";
                        break;
                }

                // Log the calculation to the file
                outFile << "Operation: " << choice << ", Result: " << x << "\n";
            } else if (choice != 21) {
                outFile << "Invalid input. Please enter a number between 1 and 21.\n";
            }
        } else {
            // Handle non-integer input
            outFile << "Invalid input. Please enter a number.\n";
            cin.clear();  // clear the error flag
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  // discard invalid input
        }

    } while (choice != 21);

    outFile.close(); // Close the file
    return 0;
}
