//   MUBINA MOHAMMED ALI   ROLL # 193
//   LAIBA ARSHAD          ROLL # 093


#include <bits/stdc++.h>
using namespace std;
const int BOARD_SIZE = 100;


//function prototypes
void boardDisplay(int &P1, int &P2);
void board();
void gamescore(const char name1[], const char name2[], int p1, int p2);
void play_dice(int &score);
void wait();


int main()          //maaainnnnnnn functionnnn
{
    int player1 = 0, player2 = 0, lastposition;
    char player1name[80], player2name[80];
    
    cout << "\n\n\n\t\tSNAKE LADDER GAME\n\n\n";
    wait();
    system("cls");
    
    cout << "\n\nEnter Name of player 1: ";
    cin>>player1name;
    cout << "\nEnter Name of player 2: ";
    cin>>player2name;

    while (player1 <= BOARD_SIZE && player2 <= BOARD_SIZE)
    {
    	system("cls");
        board();
        gamescore(player1name, player2name, player1, player2); //p1 amd p2 were formal parametres also name1 and name 2.
        
        cout << "\n\n--->" << player1name << " Now your Turn >> Press any key to play ";
        cin.ignore(); //ignore previous newline character, essential for first turn otherwise it will directly play the dice (happens only 1 time)
        cin.get();
         //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        lastposition = player1;
        play_dice(player1);
        
        
		boardDisplay(player1, player2);
	
        if (player1 < lastposition)
            cout << "\n\aOops!! Snake found !! You are at position " << player1 << "\n";
        else if (player1 > lastposition + 6)
            cout << "\nGreat!! you got a ladder !! You are at position " << player1;
		 //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        cout << "\n\n--->" << player2name << " Now your Turn >> Press any key to play ";
        cin.get();
        
        lastposition = player2;
        play_dice(player2);
        
        boardDisplay(player1, player2);
        		
        if (player2 < lastposition)
            cout << "\n\n\aOops!! Snake found !! You are at position " << player2 << "\n";
        else if (player2 > lastposition + 6)
            cout << "\n\nGreat!! you got a ladder !! You are at position " << player2 << "\n";
        
        cin.ignore(); //ignore previous newline character also , if we dont use cin.ignore, it will proceed without showing output
    }
	             
	
    cout << "\n\n\n";
    cout << "\n\n\t\tRESULT\n\n";
    cout << endl;
    gamescore(player1name, player2name, player1, player2);
    cout << "\n\n\n";

    if (player1 >= player2)
        cout << player1name << " !! You are the winner of the game\n\n";
    else
        cout << player2name << " !! You are the winner of the game\n\n";
    cin.get();
}


            //FUNCTION DEFINITIONNNNNNNNNNNN
string boards [11][11];
void boardDisplay(int &P1, int &P2)          
{
	int r, r1, r2, c, c1, c2;
		
		for(r=1; r<11; r++)
			{
			for(c=1; c<11; c++)
				{
				boards [r][c] = " ";
				}	
			}
	
	r1= (P1/10)+1;	//P1 / 10 divides the current position of Player 1 by 10. This essentially groups the positions into sets of 10, determining which row they fall into.
					//The addition of 1 (+ 1) ensures that the row indices start from 1, not 0. This is because array indices typically start from 0.
	c1 = P1 % 10;	//The modulo operation helps find the remainder when dividing by 10, giving the column position within the row.
					//It simplifies the calculation and eliminates the need for additional adjustments.
	
	boards [r1][c1]= " P1 ";
		
	r2= (P2/10)+1;	
	c2 = P2 % 10;
	
	boards [r2][c2] = " P2 ";
	
	if(P1==P2)
	{
		boards [r2][c2] = "P1P2";
	}
	
		for(r=1; r<11; r++)
		{
					cout<<"\n";
			for(c=1; c<11; c++)
			{
				if(boards [r][c] == " ")
				{
					boards [r][c] = " -- ";
				}
			cout<<boards [r][c];
			
			}

		}
}


void board()
{	

    // Replace the following line with the appropriate command for Windows
    system("cls");
    
    cout << "\t\tSNAKE AT POSITION";
    cout << "\n\tFrom 98 to 28 \tFrom 95 to 24\n\tFrom 92 to 51\tFrom 83 to 19\n\tFrom 73 to 1\tFrom 69 to 33\n\tFrom 64 to 36\tFrom 59 to 17\n\tFrom 55 to 7\tFrom 52 to 11\n\tFrom 48 to 9\tFrom 46 to 5\n\tFrom 44 to 22\n";
    cout << "\n\t\t LADDER AT POSITION";
    cout << "\n\tFrom 8 to 26\tFrom 21 to 82\n\tFrom 43 to 77\tFrom 50 to 91\n\tFrom 62 to 96\tFrom 66 to 87\n\tFrom 80 to 100\n";
    cout << endl;
}

void gamescore(const char name1[], const char name2[], int p1, int p2) 
{
    cout << "\n\t\tGAME STATUS\n";
    cout << "\t--->" << name1 << " is at position " << p1 << endl;
    cout << "\t--->" << name2 << " is at position " << p2 << endl;
    cout << endl;
}

void play_dice(int &score) //If you dont write '&', it would still work, but the modifications to the score variable inside the function would only be local to the function. 
{                        //The original player1 and player2 variables in the main function would not be updated
                      //In summary, using int score instead of int &score would result in the modifications made to score inside the function being local to the function and 
					  //not affecting the original variable passed as an argument.
    int dice;
    srand(time(NULL));  //seeds rand, basically make a random seq for rand function
    dice = rand() % 6 + 1;	//eg  602%6 =2 so 2+1=3
    cout << "\nYou got " << dice << " Point !! ";
    score = score + dice;
    cout << "Now you are at position " << score;

    switch (score) 
    {				//snakes
    case 98:    
		score = 28; break;
    case 95:    
		score = 24; break;
    case 92:    
		score = 51; break;
    case 83:    
		score = 19; break;
    case 73:    
		score = 1; break;
    case 69:    
		score = 33; break;
    case 64:    
		score = 36; break;
    case 59:    
		score = 17; break;
    case 55:    
		score = 7; break;
    case 52:    
		score = 11; break;
    case 48:    
		score = 9; break;
    case 46:    
		score = 5; break;
    case 44:    
		score = 22; break;
					//ladders
    case 8:     
		score = 26; break;
    case 21:    
		score = 82; break;
    case 43:    
		score = 77; break;
    case 50:    
		score = 91; break;
    case 54:    
		score = 93; break;
    case 62:    
		score = 96; break;
    case 66:    
		score = 87; break;
    case 80:    
		score = 99; break;
    }
}

void wait()
{
	
cout << "\n\t\tloading";
for(int i = 1; i <= 5; i++)
{
	cout << ".";
	sleep(1);
}

}