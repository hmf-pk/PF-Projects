                      //LAIBA MAJEED(125),HIBA ALI(177)
                      
                      
#include<bits/stdc++.h>
using namespace std;
int shop(int categorie){
		//ALL SHOPS OF OUR STORE
	cout<<"CHOOSE YOUR FAVOURITE SHOP "<<endl;
    cout<<"1. Appliances shop\n2. Sports Item shop\n3. Fruit shop\n4. Bakery shop\n5. Perfumes shop\n6. End\nEnter choice (1-6):"<<endl;
	return categorie;
}
int main(){
int categorie;
cout << "\n\nWELCOME TO VIRTUAL SHOPPING MALL\n\n";
while (categorie != 6) {
	int result= shop(categorie);
    cout<<"Choose your Category (1-6): ";
    cin>>categorie;
switch (categorie){
case 1:
system("CLS");
         {
         	cout << "Entering in the shop" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
	
	    //YOU ARE IN THE APPLIANCES SHOP
       {
		cout << "\n------------------WELCOME TO APPLIANCES SHOP------------------ " << endl;
             //PRODUCT'S PRICES
        double pricespeaker= 6.6, priceoven= 8.0, pricechopper= 12.5, priceiron= 8.6;
        int speakerquantity=0, ovenquantity=0, chopperquantity=0, ironquantity=0;
        int appliances=0;
        while(appliances!=5){
        	cout<<"\nCHOOSE YOUR FAVOURITE PRODUCTS"<<endl;
        	cout<<"1. Speakers: $ "<<pricespeaker<<"\n2. Oven: $ "<<priceoven<<"\n3. Chopper: $ "<<pricechopper<<"\n4. Iron: $ "<<priceiron<<"\n5. Checkout "<<"\nEnter choice (1-5):"<<endl;
        	cin>>appliances;
        switch (appliances) {
        case 1:
        	//FOR SPEAKERS
            cout<<"Enter the quantity of Speakers you want to buy: ";
            cin>>speakerquantity;
            break;
        case 2:
        	//FOR OVENS
            cout<<"Enter the quantity of Ovens you want to buy: ";
            cin>>ovenquantity;
            break;
        case 3:
        	//FOR CHOPPERS
            cout<<"Enter the quantity of Choppers you want to buy: ";
            cin>>chopperquantity;
            break;
        case 4:
        	//FOR IRONS
            cout<<"Enter the quantity of Irons you want to buy: ";
            cin>>ironquantity;
            break;
        case 5:
        	system("CLS");
         {
         	cout << "Checking out" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
         	  //TOTAL BILL FOR THIS SHOP
        double totalCost= speakerquantity*pricespeaker + ovenquantity*priceoven + chopperquantity*pricechopper + ironquantity*priceiron ;
            cout << "\n_____________________________________________________________________\n---------------BILL--------------" << endl;
            cout << "Your total bill is: $" << totalCost << endl;
            cout << "THANKS FOR VISITING THE APPLIANCES SHOP!\n_____________________________________________________________________" << endl;
            break;
            }
        default:
        cout << "Enter a valid choice from 1, 2, 3, 4 or 5" << endl;
        break;
                        }
                    }
        break;
    }
}
case 2:
	system("CLS");
         {
         	cout << "Entering in the shop" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
	  //YOU ARE IN THE SPORTS ITEMS SHOP
       {  
	cout << "\n------------------WELCOME TO SPORTS ITEMS SHOP------------------" << endl;
       //PRODUCT'S PRICES
        double pricebat= 3.0, priceball= 1.2, pricefootball= 4.5, pricebasketball= 4.6;
        int batquantity=0, ballquantity=0, footballquantity=0, basketballquantity=0;
        int sportsitem=0;
        while(sportsitem!=5){
        	cout<<"\nCHOOSE YOUR FAVOURITE PRODUCTS"<<endl;
        	cout<<"1. Bat: $ "<<pricebat<<"\n2. Ball: $ "<<priceball<<"\n3. Football: $ "<<pricefootball<<"\n4. Basketball: $ "<< pricebasketball<<"\n5. Checkout "<<"\nEnter choice (1-5): "<<endl;
        	cin>>sportsitem;
        switch (sportsitem) {
        case 1:
        	//FOR BATS
            cout<<"Enter the quantity of Bats you want to buy: ";
            cin>>batquantity;
            break;
        case 2:
        	//FOR BALLS
            cout<<"Enter the quantity of Balls you want to buy: ";
            cin>>ballquantity;
            break;
        case 3:
        	//FOR FOOTBALLS
            cout<<"Enter the quantity of Footballs you want to buy: ";
            cin>>footballquantity;
            break;
        case 4:
        	//FOR BASKETBALLS
            cout<<"Enter the quantity of Basketballs you want to buy: ";
            cin>>basketballquantity;
            break;
        case 5:
        system("CLS");
         {
         	cout << "Checking out" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
         	//TOTAL BILL FOR THIS SHOP
        double totalCost= batquantity*pricebat + ballquantity*priceball + footballquantity*pricefootball + basketballquantity* pricebasketball ;
            cout << "\n_____________________________________________________________________\n---------------BILL--------------" << endl;
            cout << "Your total bill is: $" << totalCost << endl;
            cout << "THANKS FOR VISITING THE SPORTS ITEMS SHOP!\n_____________________________________________________________________" << endl;
            break;
            }
        default:
        cout << "Enter a valid choice from 1, 2, 3, 4 or 5!" << endl;
        break;
                        }
                    }
        break;
    }
}
case 3:
	system("CLS");
         {
         	cout << "Entering in the shop" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
	//YOU ARE IN THE FRUIT SHOP
    {
    cout << "\n------------------WELCOME TO FRUIT SHOP------------------" << endl;
    //PRICES
    double priceapple = 1.50, pricebanana = 0.85, priceorange = 3.3, pricegrapes= 3.0;
    int applequantity = 0, bananaquantity = 0, orangequantity = 0, grapesquantity=0;
    int fruitchoice = 0;
    while (fruitchoice != 5) {
    	cout<<"\nCHOOSE YOUR FAVOURITE PRODUCTS"<<endl;
        cout <<"1. Apples: $"<<priceapple<<"\n2. Bananas: $"<<pricebanana<<"\n3. Oranges: $"<<priceorange<<"\n4. Grapes: $"<<pricegrapes<<"\n5. Checkout" <<"\nEnter choice (1-5): "<<endl;
        cin >> fruitchoice;
        switch (fruitchoice) {
        case 1:
        	//FOR APPLES
            cout<<"Enter the quantity of Apples you want to buy: ";
            cin>>applequantity;
            break;
        case 2:
        	//FOR BANANAS
            cout<<"Enter the quantity of Bananas you want to buy: ";
            cin>>bananaquantity;
            break;
        case 3:
        	//FOR ORANGES
            cout<<"Enter the quantity of Oranges you want to buy: ";
            cin>>orangequantity;
            break;
        case 4:
        	//FOR GRAPES
            cout << "Enter the quantity of Grapes you want to buy: ";
            cin >> grapesquantity;
            break;
        case 5:
        	system("CLS");
         {
         	cout << "Checking out" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
        	//TOTAL BILL FOR THIS SHOP
        double totalCost = applequantity*priceapple + bananaquantity*pricebanana + orangequantity*priceorange + grapesquantity*pricegrapes ;
            cout << "\n_____________________________________________________________________\n---------------BILL--------------" << endl;
            cout << "Your total bill is: $" << totalCost << endl;
            cout << "THANKS FOR VISITING THE FRUIT SHOP!\n_____________________________________________________________________" << endl;
            break;
            }
        default:
            cout << "Enter a valid choice from 1, 2, 3, 4 or 5!" << endl;
            break;
                        }
                }
        break;
    }
}
case 4:
	system("CLS");
         {
         	cout << "Entering in the shop" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
	            //YOU ARE IN THE BAKERY SHOP              
       {      
	cout << "\n------------------WELCOME TO BAKERY SHOP------------------" << endl;
             //PRODUCT'S PRICES
        double pricecake= 3.0, pricecookie= 0.5, pricedonut= 0.5, pricejuice= 1.0;
        int cakequantity=0, cookiequantity=0, donutquantity=0, juicequantity=0;
        int bakery=0;
        while(bakery!=5){
        	cout<<"\nCHOOSE YOUR FAVOURITE PRODUCTS"<<endl;
        	cout<<"1. Cake: $ "<<pricecake<<"\n2. Cookie: $ "<<pricecookie<<"\n3. Donut: $ "<<pricedonut<<"\n4. Juice: $ "<< pricejuice<<"\n5. Checkout "<<"\nEnter choice (1-5): "<<endl;
        	cin>>bakery;
        switch (bakery) { 
        case 1:
        	//FOR CAKES
            cout<<"Enter the quantity of Cakes you want to buy: ";
            cin>>cakequantity;
            break;
        case 2:
        	//FOR COOKIES
            cout<<"Enter the quantity of Cookies you want to buy: ";
            cin>>cookiequantity;
            break;
        case 3:
        	//FOR DONUTS
            cout<<"Enter the quantity of Donuts you want to buy: ";
            cin>>donutquantity;
            break;
        case 4:
        	//FOR JUICES
            cout<<"Enter the quantity of Juice you want to buy: ";
            cin>>juicequantity;
            break;
        case 5:
    system("CLS");
         {
         	cout << "Checking out" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
        	//TOTAL BILL FOR THIS SHOP	
        double totalCost= cakequantity*pricecake + cookiequantity*pricecookie + donutquantity*pricedonut + juicequantity* pricejuice ;
            cout << "\n_____________________________________________________________________\n---------------BILL--------------" << endl;
            cout << "Your total bill is: $" << totalCost << endl;
            cout << "THANKS FOR VISITING THE BAKERY SHOP!\n_____________________________________________________________________" << endl;
            break;
            }
        default:
        cout << "Enter a valid choice from 1, 2, 3, 4 or 5!" << endl;
        break;
                        }
                    }
        break;
    }
}
case 5:
	system("CLS");
         {
         	cout << "Entering in the shop" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
	                //YOU ARE IN THE PERFUME'S SHOP
        {    
	cout << "\n------------------WELCOME TO PERFUMES SHOP------------------" << endl;
             //PRODUCT'S PRICES
        double priceblueberry= 5.0, pricejdot= 4.2, pricehemani= 4.5, pricegucci= 5.6;
        int blueberryquantity=0, jdotquantity=0, hemaniquantity=0, gucciquantity=0;
        int perfumes=0;
        while(perfumes!=5){
        	cout<<"\nCHOOSE YOUR FAVOURITE PRODUCTS"<<endl;
        	cout<<"1. BlueBerry: $ "<<priceblueberry<<"\n2. J dot: $ "<<pricejdot<<"\n3. Hemani: $ "<<pricehemani<<"\n4. Guccil: $ "<< pricegucci<<"\n5. Checkout"<<"\nEnter choice (1-5): "<<endl;
        	cin>>perfumes;
        switch (perfumes) { 
        case 1:
        	//FOR BLUEBERRY
            cout<<"Enter the quantity of Blue Berry you want to buy: ";
            cin>>blueberryquantity;
            break;
        case 2:
        	//FOR JDOT
            cout<<"Enter the quantity of J dot you want to buy: ";
            cin>>jdotquantity;
            break;
        case 3:
        	//FOR HEMANI
            cout<<"Enter the quantity of Hemani you want to buy: ";
            cin>>hemaniquantity;
            break;
        case 4:
        	//FOR GUCCI
            cout<<"Enter the quantity of Gucci you want to buy: ";
            cin>>gucciquantity;
            break;
        case 5:
        system("CLS");
         {
         	cout << "Checking out" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
        	//TOTAL BILL FOR THIS SHOP
        double totalCost= blueberryquantity*priceblueberry + jdotquantity*pricejdot + hemaniquantity*pricehemani + gucciquantity*pricegucci ;
            cout << "\n_____________________________________________________________________\n---------------BILL--------------" << endl;
            cout << "Your total bill is: $" << totalCost << endl;
            cout << "THANKS FOR VISITING THE PERFUMES SHOP!\n_____________________________________________________________________" << endl;
            break;
            }
        default:
        cout << "Enter a valid choice from 1, 2, 3, or 4!" << endl;
        break;
                        }
                    }
        break;
    }
}
case 6:
	system("CLS");
         {
         	cout << "Ending of your shopping" ;
         	for(int i = 1 ; i<=3 ; i++){
         		cout<<".";
        		sleep(1);
			 }
                cout << "\n__________________________________\nThank you for shopping with us!\n__________________________________" << endl;
                break;
default:
                cout << "Enter a valid choice from 1 to 6." << endl;
                break;
        }

}

}
    return 0;
}