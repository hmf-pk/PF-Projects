#include<iostream>
using namespace std;
//Structure to store book details
struct Book 
{
    string title;
    string author;
    int id;
    bool available;
};
//Function to display book details
void displayBook(const Book& book)
{
    cout << "Title: " << book.title << endl;
    cout << "Author: " << book.author << endl;
    cout << "ID: " << book.id << endl;
    cout << "Availability: " << (book.available ? "Available" : "Not available") << endl;
    cout << endl;
}
//Function to borrow a book
void borrowBook(Book & book) 
{
    if (book.available) 
	{
        book.available = false;
        cout << "Book with ID " << book.id << " has been borrowed." << endl;
    } else 
	{
        cout << "Book with ID " << book.id << " is not available for borrowing." << endl;
    }
    cout << endl;
}
//Function to return a book
void returnBook(Book& book) 
{
    if (!book.available) {
        book.available = true;
        cout << "Book with ID " << book.id << " has been returned." << endl;
    } else {
        cout << "Book with ID " << book.id << " is already available." << endl;
    }
    cout << endl;
}
int main() {
    int MAX_BOOKS = 3;
    Book library[MAX_BOOKS];
    // Adding books to the library
    library[0] ={ "Harry Potter and the Philosopher's Stone", "J.K. Rowling", 1, true };
    library[1] ={ "Harry Potter and the Chamber of Secrets" ,  "J.K. Rowling", 2, true };
    library[2] ={ "Harry Potter and the Prisoner of Azkaban", "J.K. Rowling", 3, true };
    // Displaying all books in the library
    cout << "Library Books:" << endl;
    for (int i = 0; i < MAX_BOOKS; i++) {
        displayBook(library[i]);
    }
    // User choices
    int choice;
    while (true) {
        cout << "Enter your choice:" << endl;
        cout << "1. Borrow a book" << endl;
        cout << "2. Return a book" << endl;
        cout << "3. Add more books" << endl;
        cout << "4. Exit" << endl;
        cout << "Choice: ";
        cin >> choice;
        cout << endl;

        if (choice == 1) {
            int bookId;
            cout << "Enter the book ID to borrow: ";
            cin >> bookId;
            cout << endl;

            bool found = false;
            for (int i = 0; i < MAX_BOOKS; i++) {
                if (library[i].id == bookId) {
                    borrowBook(library[i]);
                    found = true;
                    break;
                }
            }

            if (!found) {
                cout << "Book with ID " << bookId << " not found in the library." << endl;
            }
        } else if (choice == 2) {
            int bookId;
            cout << "Enter the book ID to return: ";
            cin >> bookId;
            cout << endl;

            bool found = false;
            for (int i = 0; i < MAX_BOOKS; i++) {
                if (library[i].id == bookId) {
                    returnBook(library[i]);
                    found = true;
                    break;
                }
            }

            if (!found) {
                cout << "Book with ID " << bookId << " not found in the library." << endl;
            }
        } else if (choice == 3) {
            int numBooks;
            cout << "Enter the number of books to add: ";
            cin >> numBooks;
            cout << endl;

             int newMaxBooks = MAX_BOOKS + numBooks;

            if (newMaxBooks > sizeof(library) / sizeof(library[0])) {
                cout << "Cannot add more books. Library is full." << endl;
            } else {
                for (int i = MAX_BOOKS; i < MAX_BOOKS + numBooks; i++) {
                    cout<<"Enter details for book " << i + 1 << ":" << endl;
                    cout<<"Title: ";
                    cin.ignore();
                    getline(cin, library[i].title);
                    cout<<"Author: ";
                    getline(cin, library[i].author);
                    cout<<"ID: ";
                    cin>>library[i].id;
                    library[i].available = true;
                    cout<<endl;
                }
                MAX_BOOKS=newMaxBooks;
            }
        } else if (choice == 4) {
            break;
        } else 
		{
            cout << "Invalid choice. Please try again." << endl;
            cout << endl;
        }
    }
    cout << "Thank you for using the library management system!" << endl;
    return 0;
}
