#include <iostream>
#include <string>

using namespace std;

struct Degree {
    string name;
    string code;
};

struct Student {
    string name;
    string rollNo;
    Degree degrees[5]; // Assuming a student can have up to 5 degrees
};

struct Teacher {
    string name;
    string id;
    Degree degrees[5]; // Assuming a teacher can have up to 5 degrees
};

Degree degrees[10]; // Assuming there can be up to 10 degrees
Student students[100]; // Assuming there can be up to 100 students
Teacher teachers[50]; // Assuming there can be up to 50 teachers

int studentCount = 0;
int teacherCount = 0;
int degreeCount = 0;

void addStudent() {
    string name;
    string rollNo;

    cout << "Enter Name: ";
    getline(cin, name);
    cout << "Enter Roll No: ";
    getline(cin, rollNo);

    students[studentCount].name = name;
    students[studentCount].rollNo = rollNo;

    studentCount++;
}

void addTeacher() {
    string name;
    string id;

    cout << "Enter Name: ";
    getline(cin, name);
    cout << "Enter ID: ";
    getline(cin, id);

    teachers[teacherCount].name = name;
    teachers[teacherCount].id = id;

    teacherCount++;
}

void addDegree() {
    string name;
    string code;

    cout << "Enter Degree Name: ";
    getline(cin, name);
    cout << "Enter Degree Code: ";
    getline(cin, code);

    degrees[degreeCount].name = name;
    degrees[degreeCount].code = code;

    degreeCount++;
}

void displayStudents() {
    if (studentCount == 0) {
        cout << "No students" << endl;
    } else {
        cout << "Name                Roll No" << endl;
        for (int i = 0; i < studentCount; i++) {
            cout << students[i].name << "        " << students[i].rollNo << endl;
        }
    }
}

void displayTeachers() {
    if (teacherCount == 0) {
        cout << "No teachers" << endl;
    } else {
        cout << "Name                ID" << endl;
        for (int i = 0; i < teacherCount; i++) {
            cout << teachers[i].name << "        " << teachers[i].id << endl;
        }
    }
}

void displayDegrees() {
    if (degreeCount == 0) {
        cout << "No degrees" << endl;
    } else {
        cout << "Degree Name                Degree Code" << endl;
        for (int i = 0; i < degreeCount; i++) {
            cout << degrees[i].name << "        " << degrees[i].code << endl;
        }
    }
}

int main() {
    int choice;
        cout << "=============Lahore Garrison University=============" << endl << endl;
        cout << "=============Submitted to Sir Qadir =============" << endl << endl;
        cout << "=============Represented by Ahsan and Asma=============" << endl << endl;
    for (;;) {
        
        
        cout << "=====================" << endl;
        cout << "[1] ADD STUDENT" << endl;
        cout << "[2] ADD TEACHER" << endl;
        cout << "[3] ADD DEGREE" << endl;
        cout << "[4] DISPLAY STUDENTS" << endl;
        cout << "[5] DISPLAY TEACHERS" << endl;
        cout << "[6] DISPLAY DEGREES" << endl;
        cout << "[7] EXIT" << endl;
        cout << "=====================" << endl;
        cout << "Enter choice : ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                addTeacher();
                break;
            case 3:
                addDegree();
                break;
            case 4:
                displayStudents();
                break;
            case 5:
                displayTeachers();
                break;
            case 6:
                displayDegrees();
                break;
            case 7:
                cout << "Thank you for coming. Exiting the program." << endl;
                return 0; 
            default:
                return 0;
        }

        cout << "\n\nPress Enter to return to the menu\n";
        cin.get();
        system("cls");
        
    }
    return 0;
}
