#include<iostream>
using namespace std;
int main()
{
	int num1,num2;
	char op,option;
	start:
	system("cls");
	cout<<"Enter first number: ";
	cin>>num1;
	cout<<"Enter the operator (+, -, *, /): ";
	cin>>op;
	cout<<"Enter Second Number: ";
	cin>>num2;
	switch(op)
	{
		case '+':
			cout<<num1<<" + "<<num2<<" = "<<(num1+num2)<<endl;
			break;
		case '-':
			cout<<num1<<" - "<<num2<<" = "<<(num1-num2)<<endl;
			break;
		case '*':
			cout<<num1<<" * "<<num2<<" = "<<(num1*num2)<<endl;
			break;
		case '/':
			cout<<num1<<" / "<<num2<<" = "<<(num1/num2)<<endl;
			break;
		default:
			cout<<"Operator is Invalid: ";
			break;
	}
	cout<<"Do you want to continue the program (Y/N): ";
	cin>>option;
	if(option=='y' || option=='Y')
	   goto start;
	return 0;
}
